import { Abortable, AsyncTask, IAsyncTaskConstraint, IAsyncTaskInput, IOptionalAbortableOptions } from '@lirx/async-task';
import { IUnsubscribeOfObservable } from '@lirx/core';
import { IPushSourceWithBackPressure } from '@lirx/stream';

export type IThingValue =
  | null
  | boolean
  | number
  | string
  | object
  | IThingValue[]
  ;

export interface IConsumedThingPropertyReadOptions extends IOptionalAbortableOptions {

}

export interface IConsumedThingPropertyWriteOptions extends IOptionalAbortableOptions {

}

export abstract class ConsumedThingProperty<GValue extends IAsyncTaskConstraint<GValue, IThingValue>> {
  abstract get observe(): IPushSourceWithBackPressure<GValue>;

  abstract read(
    options?: IConsumedThingPropertyReadOptions,
  ): AsyncTask<GValue>;

  abstract write(
    value: GValue,
    options?: IConsumedThingPropertyWriteOptions,
  ): AsyncTask<void>;
}

