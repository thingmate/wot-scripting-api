export * from './consumed-thing-property.class';

