export interface ISmartPlugConsumptionHistory {
  power: number;
  start: number; // start date as timestamp in ms
  end: number; // end date as timestamp in ms
}
