import { IConsumedThing } from '../../__wot/traits/consumed-thing/consumed-thing.trait-collection';
import { ISmartPlugConfig } from './smart-plug-config.type';

export type ISmartPlugConsumedThing = IConsumedThing<ISmartPlugConfig>;

