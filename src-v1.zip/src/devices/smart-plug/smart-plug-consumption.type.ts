export interface ISmartPlugConsumption {
  current: number;
  voltage: number;
  power: number;
}
