export * from './consumed-thing/index';
