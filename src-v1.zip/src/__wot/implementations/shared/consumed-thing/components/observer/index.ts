export * from './create-consumed-thing-observer';
