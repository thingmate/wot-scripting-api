export * from './create-consumed-thing-action-from-native-consumed-thing';
