export * from './create-consumed-thing-property-from-native-consumed-thing';
