export * from './create-consumed-thing-from-wot';
