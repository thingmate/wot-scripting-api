export * from './create-exposed-thing-property-from-native-exposed-thing';
