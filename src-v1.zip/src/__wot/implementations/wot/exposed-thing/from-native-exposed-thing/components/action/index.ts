export * from './create-exposed-thing-action-from-native-consumed-thing';
