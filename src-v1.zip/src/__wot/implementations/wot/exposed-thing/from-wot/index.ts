export * from './create-exposed-thing-from-wot';
