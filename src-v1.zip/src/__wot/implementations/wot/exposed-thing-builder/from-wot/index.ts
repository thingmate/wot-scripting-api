export * from './create-exposed-thing-builder-from-wot';
