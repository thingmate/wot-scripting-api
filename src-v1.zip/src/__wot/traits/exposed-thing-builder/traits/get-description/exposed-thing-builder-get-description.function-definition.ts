import { ExposedThingInit } from 'wot-typescript-definitions';

export interface IExposedThingBuilderGetDescriptionFunction {
  (): ExposedThingInit;
}
