export * from './consumed-thing-observer.trait-collection';
export * from './traits/index';
