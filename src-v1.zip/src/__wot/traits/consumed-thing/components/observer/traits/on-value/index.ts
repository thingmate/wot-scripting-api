export * from './consumed-thing-observer-on-value.function-definition';
export * from './consumed-thing-observer-on-value.trait';
