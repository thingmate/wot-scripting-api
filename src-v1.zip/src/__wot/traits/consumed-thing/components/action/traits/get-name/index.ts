export * from './consumed-thing-action-get-name.function-definition';
export * from './consumed-thing-action-get-name.trait';
