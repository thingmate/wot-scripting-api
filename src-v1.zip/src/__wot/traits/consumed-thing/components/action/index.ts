export * from './consumed-thing-action.trait-collection';
export * from './traits/index';
