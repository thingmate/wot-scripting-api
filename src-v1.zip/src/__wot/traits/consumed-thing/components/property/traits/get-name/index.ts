export * from './consumed-thing-property-get-name.function-definition';
export * from './consumed-thing-property-get-name.trait';
