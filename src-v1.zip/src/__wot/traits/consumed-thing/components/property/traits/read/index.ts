export * from './consumed-thing-property-read.function-definition';
export * from './consumed-thing-property-read.trait';
