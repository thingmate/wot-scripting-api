export * from './consumed-thing-property-get-description.function-definition';
export * from './consumed-thing-property-get-description.trait';
