export interface IConsumedThingPropertyGetNameFunction<GName extends string> {
  (): GName;
}
