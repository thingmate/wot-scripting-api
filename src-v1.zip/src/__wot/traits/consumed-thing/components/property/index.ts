export * from './consumed-thing-property.trait-collection';
export * from './traits/index';
