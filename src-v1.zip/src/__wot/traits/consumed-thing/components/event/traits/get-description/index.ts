export * from './consumed-thing-event-get-description.function-definition';
export * from './consumed-thing-event-get-description.trait';
