export * from './consumed-thing-get-property.function-definition';
export * from './consumed-thing-get-property.trait';
