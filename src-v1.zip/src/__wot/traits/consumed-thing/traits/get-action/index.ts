export * from './consumed-thing-get-action.function-definition';
export * from './consumed-thing-get-action.trait';
