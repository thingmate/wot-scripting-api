export * from './infer-consumed-thing-action-from-name.type';
export * from './infer-consumed-thing-event-from-name.type';
export * from './infer-consumed-thing-property-from-name.type';
