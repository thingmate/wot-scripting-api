export * from './create-cached-consumed-thing-get-event-function';
