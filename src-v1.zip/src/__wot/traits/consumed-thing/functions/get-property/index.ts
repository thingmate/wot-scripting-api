export * from './create-cached-consumed-thing-get-property-function';
