export * from './create-cached-consumed-thing-get-action-function';
