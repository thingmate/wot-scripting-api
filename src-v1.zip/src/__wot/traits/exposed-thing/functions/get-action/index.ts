export * from './create-cached-exposed-thing-get-action-function';
