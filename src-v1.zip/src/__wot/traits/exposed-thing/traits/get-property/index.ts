export * from './exposed-thing-get-property.function-definition';
export * from './exposed-thing-get-property.trait';
