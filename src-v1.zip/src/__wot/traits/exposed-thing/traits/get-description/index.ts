export * from './exposed-thing-get-description.function-definition';
export * from './exposed-thing-get-description.trait';
