import { IExposedThingGetDescriptionFunction } from './exposed-thing-get-description.function-definition';

export interface IExposedThingGetDescriptionTrait {
  getDescription: IExposedThingGetDescriptionFunction;
}
