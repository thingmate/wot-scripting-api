export interface IExposedThingActionGetNameFunction<GName extends string> {
  (): GName;
}
