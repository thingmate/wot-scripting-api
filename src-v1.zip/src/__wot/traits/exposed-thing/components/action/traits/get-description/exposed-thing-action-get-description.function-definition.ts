import { ActionElement } from 'wot-thing-description-types';

export interface IExposedThingActionGetDescriptionFunction {
  (): ActionElement;
}
