export * from './exposed-thing-action-get-name.function-definition';
export * from './exposed-thing-action-get-name.trait';
