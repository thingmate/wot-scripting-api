import { IExposedThingActionGetDescriptionFunction } from './exposed-thing-action-get-description.function-definition';

export interface IExposedThingActionGetDescriptionTrait {
  getDescription: IExposedThingActionGetDescriptionFunction;
}
