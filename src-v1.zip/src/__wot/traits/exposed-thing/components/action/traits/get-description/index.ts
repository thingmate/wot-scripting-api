export * from './exposed-thing-action-get-description.function-definition';
export * from './exposed-thing-action-get-description.trait';
