export * from './exposed-thing-property-on-observe.function-definition';
export * from './exposed-thing-property-on-observe.trait';
