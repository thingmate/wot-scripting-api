export * from './exposed-thing-property-get-description.function-definition';
export * from './exposed-thing-property-get-description.trait';
