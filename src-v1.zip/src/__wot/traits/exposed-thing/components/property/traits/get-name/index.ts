export * from './exposed-thing-property-get-name.function-definition';
export * from './exposed-thing-property-get-name.trait';
