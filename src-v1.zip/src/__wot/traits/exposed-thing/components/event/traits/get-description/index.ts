export * from './exposed-thing-event-get-description.function-definition';
export * from './exposed-thing-event-get-description.trait';
