export interface IExposedThingEventGetNameFunction<GName extends string> {
  (): GName;
}
