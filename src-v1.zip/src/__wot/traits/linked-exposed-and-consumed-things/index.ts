export * from './linked-exposed-and-consumed-things.type';
