export type IWoT = typeof WoT;
