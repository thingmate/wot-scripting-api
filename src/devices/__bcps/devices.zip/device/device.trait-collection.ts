import { IDeviceOnlineTrait } from './traits/online/device-online.trait';

export interface IDevice extends // traits
  IDeviceOnlineTrait
//
{

}
