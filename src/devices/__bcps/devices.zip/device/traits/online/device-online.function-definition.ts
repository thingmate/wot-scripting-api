import { IObservable } from '@lirx/core';

export type IDeviceOnlineFunction = IObservable<boolean>;
