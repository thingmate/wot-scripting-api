import { IDeviceOnlineFunction } from './device-online.function-definition';

export interface IDeviceOnlineTrait {
  online$: IDeviceOnlineFunction;
}
