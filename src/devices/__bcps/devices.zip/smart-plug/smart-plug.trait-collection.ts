import { IDevice } from '../device/device.trait-collection';
import { ISmartPlugGetNameTrait } from './traits/get-name/smart-plug-get-name.trait';

export interface ISmartPlug extends IDevice, // traits
  ISmartPlugGetNameTrait
//
{

}
