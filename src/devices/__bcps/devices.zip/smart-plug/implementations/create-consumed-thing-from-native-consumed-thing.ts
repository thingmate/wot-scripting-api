import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThing } from '../../../wot/consumed-thing/comsumed-thing.trait-collection';
import { ISmartPlug } from '../smart-plug.trait-collection';

export function createSmartPlugFromConsumedThing(
  thing: IConsumedThing,
): ISmartPlug {
  const getName = (): string => {
    return thing.getDescription().title;
  };

  return {
    getName,
  };
}
