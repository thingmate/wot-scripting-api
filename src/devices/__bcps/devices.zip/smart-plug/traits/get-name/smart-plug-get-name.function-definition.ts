export interface ISmartPlugGetNameFunction {
  (): string;
}
