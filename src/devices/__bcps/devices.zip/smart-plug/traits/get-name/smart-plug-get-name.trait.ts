import { ISmartPlugGetNameFunction } from './smart-plug-get-name.function-definition';

export interface ISmartPlugGetNameTrait {
  getName: ISmartPlugGetNameFunction;
}
