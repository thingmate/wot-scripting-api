export type ISmartPlugState =
  | 'on'
  | 'off'
  ;
