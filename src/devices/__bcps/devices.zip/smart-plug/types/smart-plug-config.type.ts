import { ISmartPlugState } from './smart-plug-state.type';

export interface ISmartPlugConfig {
  properties: {
    state: ISmartPlugState;
  };
  actions: {
    toggle: [ISmartPlugState | undefined, ISmartPlugState],
  };
}

