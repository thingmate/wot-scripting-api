import { IConsumedThingGetDescriptionFunction } from './consumed-thing-get-description.function-definition';

export interface IConsumedThingGetDescriptionTrait {
  getDescription: IConsumedThingGetDescriptionFunction;
}
