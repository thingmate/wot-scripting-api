import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingObserverStopOptions } from '../stop/consumed-thing-observer-stop.function-definition';

export interface IStopOnSubscribeFunction {
  (): IConsumedThingObserverStopOptions | undefined;
}

export interface IConsumedThingObserverToObservableFunctionOptions {
  stopOnUnsubscribe?: IStopOnSubscribeFunction;
}

export type IConsumedThingObserverNotifications<GValue extends DataSchemaValue> = IDefaultNotificationsUnion<GValue>;

export interface IConsumedThingObserverToObservableFunction<GValue extends DataSchemaValue> {
  (
    options?: IConsumedThingObserverToObservableFunctionOptions,
  ): IObservable<IConsumedThingObserverNotifications<GValue>>;
}
