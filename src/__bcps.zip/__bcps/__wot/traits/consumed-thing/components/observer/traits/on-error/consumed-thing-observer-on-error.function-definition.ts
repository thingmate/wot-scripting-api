import { IObservable } from '@lirx/core';

export type IConsumedThingObserverOnErrorFunction = IObservable<any>;
