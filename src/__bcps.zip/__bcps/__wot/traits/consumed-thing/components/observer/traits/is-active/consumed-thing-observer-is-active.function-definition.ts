export interface IConsumedThingObserverIsActiveFunction {
  (): boolean;
}
