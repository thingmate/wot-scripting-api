import { IConsumedThingObserverIsActiveFunction } from './consumed-thing-observer-is-active.function-definition';

export interface IConsumedThingObserverIsActiveTrait {
  isActive: IConsumedThingObserverIsActiveFunction;
}
