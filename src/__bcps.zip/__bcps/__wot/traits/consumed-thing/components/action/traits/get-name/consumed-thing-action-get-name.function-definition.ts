export interface IConsumedThingActionGetNameFunction<GName extends string> {
  (): GName;
}
