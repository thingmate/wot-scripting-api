export interface IConsumedThingEventGetNameFunction<GName extends string> {
  (): GName;
}
