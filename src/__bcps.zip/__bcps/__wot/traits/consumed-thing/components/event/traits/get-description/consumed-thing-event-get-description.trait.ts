import { IConsumedThingEventGetDescriptionFunction } from './consumed-thing-event-get-description.function-definition';

export interface IConsumedThingEventGetDescriptionTrait {
  getDescription: IConsumedThingEventGetDescriptionFunction;
}
