import { ThingDescription } from 'wot-typescript-definitions';

export interface IExposedThingGetDescriptionFunction {
  (): ThingDescription;
}
