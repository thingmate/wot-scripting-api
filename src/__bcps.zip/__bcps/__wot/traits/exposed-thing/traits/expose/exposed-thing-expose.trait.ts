import { IExposedThingExposeFunction } from './exposed-thing-expose.function-definition';

export interface IExposedThingExposeTrait {
  expose: IExposedThingExposeFunction;
}
