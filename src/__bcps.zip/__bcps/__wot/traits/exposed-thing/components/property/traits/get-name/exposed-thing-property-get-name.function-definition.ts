export interface IExposedThingPropertyGetNameFunction<GName extends string> {
  (): GName;
}
