import { IExposedThingPropertyGetDescriptionFunction } from './exposed-thing-property-get-description.function-definition';

export interface IExposedThingPropertyGetDescriptionTrait {
  getDescription: IExposedThingPropertyGetDescriptionFunction;
}
