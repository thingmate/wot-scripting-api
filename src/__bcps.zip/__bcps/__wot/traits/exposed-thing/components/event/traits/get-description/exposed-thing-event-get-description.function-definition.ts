import { EventElement } from 'wot-thing-description-types';

export interface IExposedThingEventGetDescriptionFunction {
  (): EventElement;
}
