import { IExposedThingEventGetDescriptionFunction } from './exposed-thing-event-get-description.function-definition';

export interface IExposedThingEventGetDescriptionTrait {
  getDescription: IExposedThingEventGetDescriptionFunction;
}
