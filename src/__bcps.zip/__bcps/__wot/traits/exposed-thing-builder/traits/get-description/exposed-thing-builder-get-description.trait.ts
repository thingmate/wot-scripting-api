import { IExposedThingBuilderGetDescriptionFunction } from './exposed-thing-builder-get-description.function-definition';

export interface IExposedThingBuilderGetDescriptionTrait {
  getDescription: IExposedThingBuilderGetDescriptionFunction;
}
