import { AsyncTask, IAsyncTaskInput, optionalAbortableOptionsToAbortable } from '@lirx/async-task';
import { createMulticastSource } from '@lirx/core';
import { ConsumedThing, DataSchemaValue, InteractionOutput, Subscription } from 'wot-typescript-definitions';
import {
  IConsumedThingObserver,
} from '../../../../../../traits/consumed-thing/components/observer/consumed-thing-observer.trait-collection';
import {
  IConsumedThingPropertyObserveOptions,
} from '../../../../../../traits/consumed-thing/components/property/traits/observe/consumed-thing-property-observe.function-definition';
import {
  createConsumedThingObserver,
  IConsumedThingObserverUnobserveFunctionHandlerOptions,
} from '../../../../../shared/consumed-thing/components/observer/create-consumed-thing-observer';
import { consumedThingObserverModeToMethodeName, IConsumedThingObserverMode } from './consumed-thing-observer-mode';

export function createConsumedThingObserverFromNativeConsumedThing<GValue extends DataSchemaValue>(
  thing: ConsumedThing,
  name: string,
  mode: IConsumedThingObserverMode,
  options?: IConsumedThingPropertyObserveOptions,
): AsyncTask<IConsumedThingObserver<GValue>> {
  const {
    emit: $value,
    subscribe: value$,
  } = createMulticastSource<GValue>();

  const {
    emit: $error,
    subscribe: error$,
  } = createMulticastSource<any>();

  return AsyncTask.fromFactory<Subscription>(
    (): Promise<Subscription> => {
      return ((thing as any)[consumedThingObserverModeToMethodeName(mode)] as ConsumedThing['observeProperty'])(
        name,
        (data: InteractionOutput): void => {
          data.value()
            .then(
              $value as (value: DataSchemaValue) => void,
              $error,
            );
        },
        $error,
        options,
      );
    },
    optionalAbortableOptionsToAbortable(options),
  )
    .successful((
      subscription: Subscription,
    ): IConsumedThingObserver<GValue> => {
      const {
        isActive: _isActive,
        ...observer
      } = createConsumedThingObserver<GValue>({
        value$,
        error$,
        unobserveHandler: (
          {
            abortable,
            ...options
          }: IConsumedThingObserverUnobserveFunctionHandlerOptions,
        ): IAsyncTaskInput<void> => {
          return AsyncTask.fromFactory<void>(
            (): Promise<void> => {
              return subscription.stop(options);
            },
            abortable,
          );
        },
      });

      const isActive = (): boolean => {
        return subscription.active
          && _isActive();
      };

      return {
        ...observer,
        isActive,
      };
    });
}
