import { PropertyElement } from 'wot-thing-description-types';

export interface IConsumedThingPropertyGetDescriptionFunction {
  (): PropertyElement;
}
