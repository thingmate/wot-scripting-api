import { IConsumedThingPropertyGetNameFunction } from './consumed-thing-property-get-name.function-definition';

export interface IConsumedThingPropertyGetNameTrait {
  getName: IConsumedThingPropertyGetNameFunction;
}
