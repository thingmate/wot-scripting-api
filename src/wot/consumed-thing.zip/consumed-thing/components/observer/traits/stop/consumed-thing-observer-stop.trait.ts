import { IConsumedThingObserverStopFunction } from './consumed-thing-observer-stop.function-definition';

export interface IConsumedThingObserverStopTrait {
  stop: IConsumedThingObserverStopFunction;
}
