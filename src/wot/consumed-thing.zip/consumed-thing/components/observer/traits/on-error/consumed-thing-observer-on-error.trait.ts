import { IConsumedThingObserverOnErrorFunction } from './consumed-thing-observer-on-error.function-definition';

export interface IConsumedThingObserverOnErrorTrait {
  onError: IConsumedThingObserverOnErrorFunction;
}
