export interface IConsumedThingEventGetNameFunction {
  (): string;
}
