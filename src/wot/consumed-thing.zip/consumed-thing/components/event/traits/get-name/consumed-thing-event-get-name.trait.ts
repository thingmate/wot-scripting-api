import { IConsumedThingEventGetNameFunction } from './consumed-thing-event-get-name.function-definition';

export interface IConsumedThingEventGetNameTrait {
  getName: IConsumedThingEventGetNameFunction;
}
