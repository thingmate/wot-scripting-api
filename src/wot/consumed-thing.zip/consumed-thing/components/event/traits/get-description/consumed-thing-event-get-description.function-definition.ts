import { EventElement } from 'wot-thing-description-types';

export interface IConsumedThingEventGetDescriptionFunction {
  (): EventElement;
}
