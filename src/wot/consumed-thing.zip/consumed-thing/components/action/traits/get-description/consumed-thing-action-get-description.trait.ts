import { IConsumedThingActionGetDescriptionFunction } from './consumed-thing-action-get-description.function-definition';

export interface IConsumedThingActionGetDescriptionTrait {
  getDescription: IConsumedThingActionGetDescriptionFunction;
}
