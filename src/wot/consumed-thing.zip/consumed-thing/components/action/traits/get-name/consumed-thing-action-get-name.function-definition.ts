export interface IConsumedThingActionGetNameFunction {
  (): string;
}
