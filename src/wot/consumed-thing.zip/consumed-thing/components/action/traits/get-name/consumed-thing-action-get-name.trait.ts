import { IConsumedThingActionGetNameFunction } from './consumed-thing-action-get-name.function-definition';

export interface IConsumedThingActionGetNameTrait {
  getName: IConsumedThingActionGetNameFunction;
}
