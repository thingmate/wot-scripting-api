import { IConsumedThingGetEventFunction } from './consumed-thing-get-event.function-definition';

export interface IConsumedThingGetEventTrait {
  getEvent: IConsumedThingGetEventFunction;
}
