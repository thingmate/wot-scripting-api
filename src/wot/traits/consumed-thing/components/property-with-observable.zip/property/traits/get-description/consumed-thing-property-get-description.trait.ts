import { IConsumedThingPropertyGetDescriptionFunction } from './consumed-thing-property-get-description.function-definition';

export interface IConsumedThingPropertyGetDescriptionTrait {
  getDescription: IConsumedThingPropertyGetDescriptionFunction;
}
