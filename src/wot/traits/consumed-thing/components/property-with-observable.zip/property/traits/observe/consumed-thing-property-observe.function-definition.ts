import { DataSchemaValue, InteractionOptions } from 'wot-typescript-definitions';
import { IAbortablePromiseOptions } from '@lirx/promise';
import { IConsumedThingObserver } from '../../../observer/comsumed-thing-observer.trait-collection';

export interface IConsumedThingPropertyObserveOptions extends IAbortablePromiseOptions, InteractionOptions {

}

// export interface IConsumedThingPropertyObserver<GValue> {
//   onValue: IObservable<GValue>;
//   error$: IObservable<Error>;
//   stop: () => Promise<void>;
// }

export type IConsumedThingPropertyObserver<GValue extends DataSchemaValue> = IConsumedThingObserver<GValue>;

export interface IConsumedThingPropertyObserveFunction<GValue extends DataSchemaValue> {
  (
    options?: IConsumedThingPropertyObserveOptions,
  ): Promise<IConsumedThingPropertyObserver<GValue>>;
}
