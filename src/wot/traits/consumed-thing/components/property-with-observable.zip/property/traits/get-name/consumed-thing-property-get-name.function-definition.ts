export interface IConsumedThingPropertyGetNameFunction {
  (): string;
}
