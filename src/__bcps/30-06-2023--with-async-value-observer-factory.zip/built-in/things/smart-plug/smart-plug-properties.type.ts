import { IHavingOnlineThingProperty } from '../../properties/online/having-online-thing-property.type';
import { IHavingOnOffThingProperty } from '../../properties/onoff/having-on-off-thing-property.type';
import {
  IHavingPowerConsumptionHistoryThingProperty,
} from '../../properties/power-consumption-history-thing-property/having-power-consumption-history-thing-property';
import {
  IHavingPowerConsumptionThingProperty,
} from '../../properties/power-consumption-thing-property/having-power-consumption-thing-property.type';

export interface ISmartPlugProperties extends //
  IHavingOnlineThingProperty,
  IHavingOnOffThingProperty,
  IHavingPowerConsumptionThingProperty,
  IHavingPowerConsumptionHistoryThingProperty
//
{
}
