import { IThingDescription, Thing } from '../../../thing/thing.class';
import { ISmartPlugProperties } from './smart-plug-properties.type';

export type ISmartPlugThing<GDescription extends IThingDescription> = Thing<GDescription, ISmartPlugProperties>;

