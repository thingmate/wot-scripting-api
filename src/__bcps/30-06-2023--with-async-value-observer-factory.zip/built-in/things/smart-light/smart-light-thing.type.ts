import { IThingDescription, Thing } from '../../../thing/thing.class';
import { ISmartLightProperties } from './smart-light-properties.type';

export type ISmartLightThing<GDescription extends IThingDescription> = Thing<GDescription, ISmartLightProperties>;

