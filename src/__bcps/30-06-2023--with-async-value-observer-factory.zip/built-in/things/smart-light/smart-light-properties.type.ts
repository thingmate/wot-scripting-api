import { IHavingColorThingProperty } from '../../properties/color-thing-property/having-color-thing-property.type';
import { IHavingOnlineThingProperty } from '../../properties/online/having-online-thing-property.type';
import { IHavingOnOffThingProperty } from '../../properties/onoff/having-on-off-thing-property.type';

export interface ISmartLightProperties extends //
  IHavingOnlineThingProperty,
  IHavingOnOffThingProperty,
  IHavingColorThingProperty
//
{
}

