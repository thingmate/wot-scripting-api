import { AsyncValue } from '../../../async-value/async-value.class';

export type IOnlineThingProperty = AsyncValue<boolean>;

