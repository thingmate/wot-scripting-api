import { IOnlineThingProperty } from './online-thing-property.type';

export interface IHavingOnlineThingProperty {
  online: IOnlineThingProperty;
}
