import { AsyncValue } from '../../../async-value/async-value.class';
import { IRGBCW } from './type/rgb-cw.type';

export type IColorThingProperty = AsyncValue<IRGBCW>;

