import { AsyncValue } from '../../../async-value/async-value.class';
import { IPowerConsumptionHistory } from './type/power-consumption-history.type';

export type IPowerConsumptionHistoryThingProperty = AsyncValue<IPowerConsumptionHistory[]>;

