import { AsyncValue } from '../../../async-value/async-value.class';
import { IPowerConsumption } from './type/power-consumption.type';

export type IPowerConsumptionThingProperty = AsyncValue<IPowerConsumption>;

