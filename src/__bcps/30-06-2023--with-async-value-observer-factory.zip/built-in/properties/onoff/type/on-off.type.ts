export type IOnOff =
  | 'on'
  | 'off'
  ;
