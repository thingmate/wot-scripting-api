import { AsyncValue } from '../../../async-value/async-value.class';
import { IOnOff } from './type/on-off.type';

export type IOnOffThingProperty = AsyncValue<IOnOff>;

