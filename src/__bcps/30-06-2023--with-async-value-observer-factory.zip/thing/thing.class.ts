import { DeepReadonly } from '@lirx/utils';
import { IGenericAsyncValue } from '../async-value/async-value.class';

export interface IThingDescription {
  title: string;
}

export interface IThingInitOptions<GDescription extends IThingDescription, GProperties extends IThingPropertiesConstraint<GProperties>> {
  description: DeepReadonly<GDescription>;
  properties: Readonly<GProperties>;
}

export type IThingPropertiesConstraint<GProperties> = {
  [GKey in keyof GProperties]: IGenericAsyncValue;
};

export class Thing<GDescription extends IThingDescription, GProperties extends IThingPropertiesConstraint<GProperties>> {
  readonly #description: DeepReadonly<GDescription>;
  readonly #properties: Readonly<GProperties>;

  constructor(
    {
      description,
      properties,
    }: IThingInitOptions<GDescription, GProperties>,
  ) {
    this.#description = description;
    this.#properties = properties;
  }

  get description(): DeepReadonly<GDescription> {
    return this.#description;
  }

  get properties(): Readonly<GProperties> {
    return this.#properties;
  }
}

export type IGenericThing = Thing<any, any>;
