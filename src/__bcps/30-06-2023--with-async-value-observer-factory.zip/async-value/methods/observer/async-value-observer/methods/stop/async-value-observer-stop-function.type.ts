import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueObserverProducerStopFunction {
  (
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}

export interface IAsyncValueObserverConsumerStopFunction {
  (
    abortable?: Abortable,
  ): AsyncTask<void>;
}
