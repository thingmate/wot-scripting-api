export type IAsyncValueObserverState =
  | 'running'
  | 'stopping'
  | 'stopped'
  ;
