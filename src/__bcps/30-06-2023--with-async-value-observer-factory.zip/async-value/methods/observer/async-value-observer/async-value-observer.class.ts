import { Abortable, AsyncTask } from '@lirx/async-task';
import { conditional$$, createMulticastReplayLastSource, IMulticastReplayLastSource, IObservable, map$$ } from '@lirx/core';
import { IAsyncValueObserverOptions } from './async-value-observer-options.type';
import { IAsyncValueObserverState } from './methods/state/async-value-observer-state.type';
import { IAsyncValueObserverProducerStopFunction } from './methods/stop/async-value-observer-stop-function.type';

export class AsyncValueObserver<GValue> {
  readonly #value$: IObservable<GValue>;
  readonly #error$: IObservable<Error>;
  readonly #stop: IAsyncValueObserverProducerStopFunction;

  readonly #$state$: IMulticastReplayLastSource<IAsyncValueObserverState>;

  #stopTask!: AsyncTask<void>;

  constructor(
    {
      value$,
      error$,
      stop,
    }: IAsyncValueObserverOptions<GValue>,
  ) {
    this.#$state$ = createMulticastReplayLastSource<IAsyncValueObserverState>('running');

    const running$ = map$$(this.state$, (state: IAsyncValueObserverState): boolean => (state === 'running'));

    this.#value$ = conditional$$(value$, running$);
    this.#error$ = conditional$$(error$, running$);
    this.#stop = stop;
  }

  get state(): IAsyncValueObserverState {
    return this.#$state$.getValue();
  }

  get state$(): IObservable<IAsyncValueObserverState> {
    return this.#$state$.subscribe;
  }

  stop(
    abortable: Abortable = Abortable.never,
  ): AsyncTask<void> {
    if (this.state === 'running') {
      this.#$state$.emit('stopping');
      this.#stopTask = AsyncTask.fromFactory(this.#stop, abortable)
        .then(
          (): void => {
            this.#$state$.emit('stopped');
          },
          (error: unknown): never => {
            this.#$state$.emit('running');
            throw error;
          },
        );
    }

    return this.#stopTask.switchAbortable(abortable);
  }
}
