import { IObservable } from '@lirx/core';
import { IAsyncValueObserverProducerStopFunction } from './methods/stop/async-value-observer-stop-function.type';

export interface IAsyncValueObserverOptions<GValue> {
  value$: IObservable<GValue>;
  error$: IObservable<Error>;
  stop: IAsyncValueObserverProducerStopFunction;
}
