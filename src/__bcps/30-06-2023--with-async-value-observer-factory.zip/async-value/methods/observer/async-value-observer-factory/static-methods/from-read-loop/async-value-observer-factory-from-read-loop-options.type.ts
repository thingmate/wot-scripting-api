import { IAsyncTaskConstraint } from '@lirx/async-task';
import { IEqualFunction } from '@lirx/utils';
import { IAsyncValueConsumerReadFunction } from '../../../../read/async-value-read-function.type';

export interface IAsyncValueObserverFactoryFromReadLoopOptions<GValue extends IAsyncTaskConstraint<GValue>> {
  read: IAsyncValueConsumerReadFunction<GValue>;
  interval: number;
  equal?: IEqualFunction<GValue>;
}
