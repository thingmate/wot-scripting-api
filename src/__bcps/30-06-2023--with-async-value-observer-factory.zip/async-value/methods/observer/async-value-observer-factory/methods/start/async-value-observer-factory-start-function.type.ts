import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';
import { AsyncValueObserver } from '../../../async-value-observer/async-value-observer.class';

export interface IAsyncValueObserverFactoryProducerStartFunction<GValue> {
  (
    abortable: Abortable,
  ): IAsyncTaskInput<AsyncValueObserver<GValue>>;
}

export interface IAsyncValueObserverFactoryConsumerStartFunction<GValue> {
  (
    abortable?: Abortable,
  ): AsyncTask<AsyncValueObserver<GValue>>;
}
