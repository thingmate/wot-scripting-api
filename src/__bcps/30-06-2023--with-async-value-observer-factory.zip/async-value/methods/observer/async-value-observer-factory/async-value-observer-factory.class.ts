import { Abortable, AsyncTask, asyncTimeout, IAsyncTaskConstraint } from '@lirx/async-task';
import { $$distinct, createMulticastSource } from '@lirx/core';
import { AsyncValueObserver } from '../async-value-observer/async-value-observer.class';
import { IAsyncValueObserverFactoryOptions } from './async-value-observer-factory-options.type';
import { IAsyncValueObserverFactoryConsumerStartFunction } from './methods/start/async-value-observer-factory-start-function.type';
import {
  IAsyncValueObserverFactoryFromReadLoopOptions,
} from './static-methods/from-read-loop/async-value-observer-factory-from-read-loop-options.type';

export class AsyncValueObserverFactory<GValue> {

  static fromReadLoop<GValue extends IAsyncTaskConstraint<GValue>>(
    {
      read,
      interval,
      equal,
    }: IAsyncValueObserverFactoryFromReadLoopOptions<GValue>,
  ): AsyncValueObserverFactory<GValue> {
    return new AsyncValueObserverFactory<GValue>({
      start: (): AsyncValueObserver<GValue> => {
        const { emit: _$value, subscribe: value$ } = createMulticastSource<GValue>();
        const { emit: $error, subscribe: error$ } = createMulticastSource<Error>();

        const $value = $$distinct(_$value, { equal });

        const [abortLoop, loopAbortable] = Abortable.derive();

        const loop = (
          abortable: Abortable,
        ): AsyncTask<void> => {
          const start: number = Date.now();
          return read(abortable)
            .then($value, $error)
            .successful((
              _,
              abortable: Abortable,
            ): AsyncTask<void> => {
              return asyncTimeout(
                Math.max(0, interval - (Date.now() - start)),
                abortable,
              );
            })
            .successful((
              _,
              abortable: Abortable,
            ): AsyncTask<void> => {
              return loop(abortable);
            });
        };

        loop(loopAbortable);

        return new AsyncValueObserver<GValue>({
          value$,
          error$,
          stop: (): void => {
            abortLoop('unobserve');
          },
        });
      },
    });
  }

  readonly #start: IAsyncValueObserverFactoryConsumerStartFunction<GValue>;

  constructor(
    {
      start,
    }: IAsyncValueObserverFactoryOptions<GValue>,
  ) {
    this.#start = (
      abortable: Abortable = Abortable.never,
    ): AsyncTask<AsyncValueObserver<GValue>> => {
      return AsyncTask.fromFactory(start, abortable);
    };
  }

  get start(): IAsyncValueObserverFactoryConsumerStartFunction<GValue> {
    return this.#start;
  }
}
