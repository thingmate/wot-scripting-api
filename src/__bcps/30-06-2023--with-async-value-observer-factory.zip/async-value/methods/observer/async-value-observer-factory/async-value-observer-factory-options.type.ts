import { IAsyncValueObserverFactoryProducerStartFunction } from './methods/start/async-value-observer-factory-start-function.type';

export interface IAsyncValueObserverFactoryOptions<GValue> {
  start: IAsyncValueObserverFactoryProducerStartFunction<GValue>;
}
