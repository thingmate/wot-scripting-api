import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueProducerWriteFunction<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}

export interface IAsyncValueConsumerWriteFunction<GValue> {
  (
    value: GValue,
    abortable?: Abortable,
  ): AsyncTask<void>;
}
