import { Abortable, AsyncTask, IAsyncTaskConstraint, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueProducerReadFunction<GValue extends IAsyncTaskConstraint<GValue>> {
  (
    abortable: Abortable,
  ): IAsyncTaskInput<GValue>;
}

export interface IAsyncValueConsumerReadFunction<GValue extends IAsyncTaskConstraint<GValue>> {
  (
    abortable?: Abortable,
  ): AsyncTask<GValue>;
}
