import { IAsyncTaskConstraint } from '@lirx/async-task';
import { AsyncValueObserverFactory } from './methods/observer/async-value-observer-factory/async-value-observer-factory.class';
import { IAsyncValueProducerReadFunction } from './methods/read/async-value-read-function.type';
import { IAsyncValueProducerWriteFunction } from './methods/write/async-value-write-function.type';

export interface IAsyncValueInitOptions<GValue extends IAsyncTaskConstraint<GValue>> {
  read: IAsyncValueProducerReadFunction<GValue>;
  write?: IAsyncValueProducerWriteFunction<GValue> | undefined;
  observer?: AsyncValueObserverFactory<GValue> | undefined;
}
