import { Abortable, AsyncTask, IAsyncTaskConstraint, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncValueInitOptions } from './async-value-init-options.type';
import { AsyncValueObserverFactory } from './methods/observer/async-value-observer-factory/async-value-observer-factory.class';
import { IAsyncValueConsumerReadFunction } from './methods/read/async-value-read-function.type';
import { IAsyncValueConsumerWriteFunction } from './methods/write/async-value-write-function.type';

export class AsyncValue<GValue extends IAsyncTaskConstraint<GValue>> {

  // static abc<GValue extends IAsyncTaskConstraint<GValue, IAsyncValue>>(): AsyncValue<GValue> {
  //
  // }

  readonly #read: IAsyncValueConsumerReadFunction<GValue>;
  readonly #write: IAsyncValueConsumerWriteFunction<GValue> | undefined;
  readonly #observer: AsyncValueObserverFactory<GValue> | undefined;

  constructor(
    {
      read,
      write,
      observer,
    }: IAsyncValueInitOptions<GValue>,
  ) {
    this.#read = (
      abortable: Abortable = Abortable.never,
    ): AsyncTask<GValue> => {
      return AsyncTask.fromFactory(read, abortable);
    };

    this.#write = (write === void 0)
      ? void 0
      : (
        value: GValue,
        abortable: Abortable = Abortable.never,
      ): AsyncTask<void> => {
        return AsyncTask.fromFactory((abortable: Abortable): IAsyncTaskInput<void> => {
          return write(value, abortable);
        }, abortable);
      };

    this.#observer = observer;
  }

  get read(): IAsyncValueConsumerReadFunction<GValue> {
    return this.#read;
  }

  get write(): IAsyncValueConsumerWriteFunction<GValue> | undefined {
    return this.#write;
  }

  get observer(): AsyncValueObserverFactory<GValue> | undefined {
    return this.#observer;
  }
}

export type IGenericAsyncValue = AsyncValue<any>;


