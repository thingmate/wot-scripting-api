import { Abortable, AsyncTask, IAsyncTaskFactory, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { toAsyncIterable } from '@lirx/core';
import { noop } from '@lirx/utils';
import { IGenericThing } from '../thing/thing.class';
import {
  IThingDiscoveryConsumerDiscoverFunction, IThingDiscoveryConsumerDiscoverSinkFunction,
} from './methods/discover/thing-discovery-discover-function.type';
import { IThingDiscoveryInitOptions } from './thing-discovery-init-options.type';



export class ThingDiscovery<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {

  readonly #discover: IThingDiscoveryConsumerDiscoverFunction<GThing>;

  constructor(
    {
      discover,
    }: IThingDiscoveryInitOptions<GThing>,
  ) {

    this.#discover = (
      sink: IThingDiscoveryConsumerDiscoverSinkFunction<GThing>,
      abortable: Abortable = Abortable.never,
    ): AsyncTask<IteratorResult<GThing>> => {
      return AsyncTask.fromFactory();
    };
  }

  get discover(): IThingDiscoveryConsumerDiscoverFunction<GThing> {
    return this.#discover;
  }
}
