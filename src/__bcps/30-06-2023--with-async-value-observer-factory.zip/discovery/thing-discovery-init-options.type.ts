import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { IGenericThing } from '../thing/thing.class';
import { IThingDiscoveryProducerDiscoverFunction } from './methods/discover/thing-discovery-discover-function.type';

export interface IThingDiscoveryInitOptions<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  discover: IThingDiscoveryProducerDiscoverFunction<GThing>;
}
