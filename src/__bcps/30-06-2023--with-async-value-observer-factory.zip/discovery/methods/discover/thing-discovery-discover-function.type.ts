import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { IPushSinkWithBackPressure } from '@lirx/stream/src/push-sink/push-sink-with-back-pressure.type';
import { IGenericThing } from '../../../thing/thing.class';

export interface IThingDiscoveryProducerDiscoverFunction<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  (
    sink: IThingDiscoveryProducerDiscoverSinkFunction<GThing>,
    abortable: Abortable,
  ): IAsyncTaskInput<GThing>;
}

export interface IThingDiscoveryProducerDiscoverSinkFunction<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  (
    value: GThing,
    abortable: Abortable,
  ): AsyncTask<void>;
}


export interface IThingDiscoveryConsumerDiscoverFunction<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  (
    sink: IThingDiscoveryConsumerDiscoverSinkFunction<GThing>,
    abortable?: Abortable,
  ): AsyncTask<GThing>;
}

export interface IThingDiscoveryConsumerDiscoverSinkFunction<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  (
    value: GThing,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}

// export interface IDiscoverFunctionPendingResult<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
//   done: false;
//   value: GThing;
// }

// export interface IDiscoverFunctionDoneResult {
//   done: true;
//   value: undefined;
// }
//
// export type IDiscoverFunctionResult<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> =
//   | IDiscoverFunctionPendingResult<GThing>
//   | IDiscoverFunctionDoneResult
//   ;
//
//
// export const DISCOVER_FUNCTION_DONE_RESULT: IDiscoverFunctionDoneResult = {
//   done: true,
//   value: undefined,
// };
