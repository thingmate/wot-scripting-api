import { Abortable, AsyncTask, IAsyncTaskConstraint } from '@lirx/async-task';
import { IThingValue } from '../types/thing-value.type';


export abstract class ThingAction<GIn extends IThingValue, GOut extends IAsyncTaskConstraint<GOut, IThingValue>> {
  abstract invoke(
    value: GIn,
    abortable: Abortable,
  ): AsyncTask<GOut>;
}

