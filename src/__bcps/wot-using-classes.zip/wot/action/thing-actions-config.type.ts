import { IThingValue } from '../types/thing-value.type';
import { ThingAction } from './thing-action.class';

export type IThingActionsConfig = Record<string, ThingAction<IThingValue, IThingValue>>;

export interface IThingConfigActions {
  actions?: IThingActionsConfig;
}

export type InferThingActions<GConfig extends IThingConfigActions> =
  GConfig['actions'] extends undefined
    ? {}
    : GConfig['actions'];

export type InferThingActionNames<GConfig extends IThingConfigActions> =
  Extract<keyof InferThingActions<GConfig>, string>;

export type InferThingActionFromName<GConfig extends IThingConfigActions, GName extends InferThingActionNames<GConfig>> =
  InferThingActions<GConfig>[GName];
