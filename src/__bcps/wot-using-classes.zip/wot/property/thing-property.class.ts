import { Abortable, AsyncTask, IAsyncTaskConstraint } from '@lirx/async-task';
import { IPushSourceWithBackPressure } from '@lirx/stream';
import { IThingValue } from '../types/thing-value.type';

export abstract class ThingProperty<GValue extends IAsyncTaskConstraint<GValue, IThingValue>> {
  abstract read(
    abortable: Abortable,
  ): AsyncTask<GValue>;

  abstract write(
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void>;

  abstract observe(): IPushSourceWithBackPressure<GValue>;
}

