import { IThingValue } from '../types/thing-value.type';
import { ThingProperty } from './thing-property.class';

export type IThingPropertiesConfig = Record<string, ThingProperty<IThingValue>>;

export interface IThingConfigProperties {
  properties?: IThingPropertiesConfig;
}

export type InferThingProperties<GConfig extends IThingConfigProperties> =
  GConfig['properties'] extends undefined
    ? {}
    : GConfig['properties'];

export type InferThingPropertyNames<GConfig extends IThingConfigProperties> =
  Extract<keyof InferThingProperties<GConfig>, string>;

export type InferThingPropertyFromName<GConfig extends IThingConfigProperties, GName extends InferThingPropertyNames<GConfig>> =
  InferThingProperties<GConfig>[GName];
