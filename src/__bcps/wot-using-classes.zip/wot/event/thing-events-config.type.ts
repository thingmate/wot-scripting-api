import { IThingValue } from '../types/thing-value.type';
import { ThingEvent } from './thing-event.class';

export type IThingEventsConfig = Record<string, ThingEvent<IThingValue>>;

export interface IThingConfigEvents {
  events?: IThingEventsConfig;
}

export type InferThingEvents<GConfig extends IThingConfigEvents> =
  GConfig['events'] extends undefined
    ? {}
    : GConfig['events'];

export type InferThingEventNames<GConfig extends IThingConfigEvents> =
  Extract<keyof InferThingEvents<GConfig>, string>;

export type InferThingEventFromName<GConfig extends IThingConfigEvents, GName extends InferThingEventNames<GConfig>> =
  InferThingEvents<GConfig>[GName];

