import { IAsyncTaskConstraint } from '@lirx/async-task';
import { IPushSourceWithBackPressure } from '@lirx/stream';
import { IThingValue } from '../types/thing-value.type';

export abstract class ThingEvent<GValue extends IAsyncTaskConstraint<GValue, IThingValue>> {
  abstract observe(): IPushSourceWithBackPressure<GValue>;
}

