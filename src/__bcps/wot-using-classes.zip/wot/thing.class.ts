import { InferThingActionFromName, InferThingActionNames, IThingConfigActions } from './action/thing-actions-config.type';
import { InferThingEventFromName, InferThingEventNames, IThingConfigEvents } from './event/thing-events-config.type';
import { InferThingPropertyFromName, InferThingPropertyNames, IThingConfigProperties } from './property/thing-properties-config.type';

export interface IThingConfig extends //
  IThingConfigProperties,
  IThingConfigActions,
  IThingConfigEvents
//
{
}

export abstract class Thing<GConfig extends IThingConfig> {
  abstract getProperty<GName extends InferThingPropertyNames<GConfig>>(
    name: GName,
  ): InferThingPropertyFromName<GConfig, GName>;

  abstract getAction<GName extends InferThingActionNames<GConfig>>(
    name: GName,
  ): InferThingActionFromName<GConfig, GName>;

  abstract getEvent<GName extends InferThingEventNames<GConfig>>(
    name: GName,
  ): InferThingEventFromName<GConfig, GName>;
}

/*------*/

// export interface ISmartPlugConfig {
//   properties: {
//     state: ThingProperty<ISmartPlugState>;
//   };
// }
//
// const a: Thing<ISmartPlugConfig> = null as any;
//
// a.getProperty('state').write(5);
