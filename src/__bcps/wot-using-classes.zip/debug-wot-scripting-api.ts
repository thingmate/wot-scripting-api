import { Abortable, AsyncTask } from '@lirx/async-task';
import { mapPushPipeWithBackPressure } from '@lirx/stream';
import { IPushSourceWithBackPressure } from '@lirx/stream/src/push-source/push-source-with-back-pressure.type';
import {
  connectMerossDevice,
  createMerossApplianceControlToggleXAbilityListener,
  getMerossApplianceControlToggleX,
  IDeviceOptionsForCreateAndSendMerossPacketAbility,
  IMerossApplianceControlToggleXAbilityGETACKPayload, IMerossDeviceListResponseDataDeviceJSON,
  MEROSS_TOGGLE_STATE,
  setMerossApplianceControlToggleX,
} from '@thingmate/vendor-meross';
import { IForgeWebSocketUrlFunction } from '@thingmate/vendor-meross/src/device/init-meross-mqtt-client';
import {
  IMerossApplianceControlToggleXAbilityPUSHPayload,
} from '@thingmate/vendor-meross/src/device/packet/abilities/appliance-control-toggle-x/meross-appliance-control-toggle-x.type';
import { getOppositeSmartPlugState, ISmartPlugState } from '@thingmate/wot-scripting-api';
import { getWebSocketProxyUrl } from '../../misc/get-web-socket-proxy-url';
import { getMerossDevice } from '../meross/get-meross-device';
import { getMerossLoginData } from '../meross/get-meross-login-data';
import { ThingAction } from './wot/components/action/thing-action.class';
import { ThingProperty } from './wot/components/property/thing-property.class';

export function merossToggleStateToSmartPlugState(
  state: MEROSS_TOGGLE_STATE,
): ISmartPlugState {
  return (state === MEROSS_TOGGLE_STATE.ON)
    ? 'on'
    : 'off';
}

function standardSmartPlugStateToMerossToggleState(
  state: ISmartPlugState,
): MEROSS_TOGGLE_STATE {
  return (state === 'on')
    ? MEROSS_TOGGLE_STATE.ON
    : MEROSS_TOGGLE_STATE.OFF;
}

export interface IMerossSmartPlugStateThingPropertyOptions {
  deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
  channel?: number;
}

export class MerossSmartPlugStateThingProperty extends ThingProperty<ISmartPlugState> {
  #deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
  #channel: number;

  constructor(
    {
      deviceOptions,
      channel = 0,
    }: IMerossSmartPlugStateThingPropertyOptions,
  ) {
    super();
    this.#deviceOptions = deviceOptions;
    this.#channel = channel;
  }

  override read(
    abortable: Abortable,
  ): AsyncTask<ISmartPlugState> {
    return getMerossApplianceControlToggleX({
      ...this.#deviceOptions,
      payload: {
        togglex: {
          channel: this.#channel,
        },
      },
      abortable,
    })
      .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): ISmartPlugState => {
        return merossToggleStateToSmartPlugState(response.togglex.onoff);
      });
  }

  override write(
    value: ISmartPlugState,
    abortable: Abortable,
  ): AsyncTask<void> {
    return setMerossApplianceControlToggleX({
      ...this.#deviceOptions,
      payload: {
        togglex: {
          channel: this.#channel,
          onoff: standardSmartPlugStateToMerossToggleState(value),
        },
      },
      abortable,
    })
      .successful(() => {
      });
  }

  override observe(): IPushSourceWithBackPressure<ISmartPlugState> {
    return mapPushPipeWithBackPressure(
      createMerossApplianceControlToggleXAbilityListener(this.#deviceOptions),
      (
        payload: IMerossApplianceControlToggleXAbilityPUSHPayload,
      ): ISmartPlugState => {
        return merossToggleStateToSmartPlugState(payload.togglex[this.#channel].onoff);
      },
    );
  }
}

/*---------*/

export interface IMerossSmartPlugStateThingActionOptions {
  deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
  channel?: number;
}

export class MerossSmartPlugToggleThingProperty extends ThingAction<ISmartPlugState | null, ISmartPlugState> {
  #deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
  #channel: number;
  #stateProperty: MerossSmartPlugStateThingProperty;

  constructor(
    {
      deviceOptions,
      channel = 0,
    }: IMerossSmartPlugStateThingActionOptions,
  ) {
    super();
    this.#deviceOptions = deviceOptions;
    this.#channel = channel;
    this.#stateProperty = new MerossSmartPlugStateThingProperty({
      deviceOptions,
      channel,
    });
  }

  override invoke(
    value: ISmartPlugState | null,
    abortable: Abortable,
  ): AsyncTask<ISmartPlugState> {
    const getState = (
      abortable: Abortable,
    ): AsyncTask<ISmartPlugState> => {
      return (value === null)
        ? this.#stateProperty.read(abortable)
          .successful(getOppositeSmartPlugState)
        : AsyncTask.success(value, abortable);
    };

    return getState(abortable)
      .successful((state: ISmartPlugState, abortable: Abortable): AsyncTask<ISmartPlugState> => {
        return this.#stateProperty.write(state, abortable)
          .successful((): ISmartPlugState => {
            return state;
          });
      });
  }
}

/*---------*/

const forgeWebSocketUrlFunction: IForgeWebSocketUrlFunction = (url: URL): URL => {
  return getWebSocketProxyUrl({
    hostname: url.hostname,
    port: Number(url.port),
    protocol: 'mqtt',
  });
};

/*---------*/

export async function debugWotScriptingApi() {
  const abortable = Abortable.never;

  const loginData = await getMerossLoginData(abortable)
    .toPromise();

  const device: IMerossDeviceListResponseDataDeviceJSON = await getMerossDevice(abortable)
    .toPromise();

  const deviceOptions = await connectMerossDevice({
    hostname: device.domain,
    deviceId: device.uuid,
    userId: loginData.userid,
    key: loginData.key,
    abortable,
    forgeWebSocketUrlFunction,
    // forgeHttpMerossPacketUrlFunction,
  })
    .toPromise();

  const stateProperty = new MerossSmartPlugStateThingProperty({
    deviceOptions,
  });

  stateProperty.observe()((state: ISmartPlugState, abortable: Abortable): AsyncTask<void> => {
    console.log('state', state);
    return AsyncTask.void(abortable);
  }, abortable);

  // console.log(await stateProperty.read(abortable).toPromise());
  // console.log(await stateProperty.write('off', abortable).toPromise());

  const toggleAction = new MerossSmartPlugToggleThingProperty({
    deviceOptions,
  });

  // toggleAction.invoke(null, abortable);
}
