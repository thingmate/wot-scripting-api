import { fromPromiseFactory, IDefaultNotificationsUnion, IObservable, isMaybeObservable, toReadableStream, IObserver } from '@lirx/core';
import { ConsumedThing, DataSchemaValue, InteractionInput, InteractionOptions, InteractionOutput } from 'wot-typescript-definitions';
import { IInteractionInput } from '../../interaction-input/interaction-input.type';
import {
  createInteractionOutputFromNativeInteractionOutput
} from '../../interaction-output/implementations/create-interaction-output-from-native-interaction-output';
import { IInteractionOutput } from '../../interaction-output/interaction-output.trait-collection';
import { IConsumedThing } from '../comsumed-thing.trait-collection';

export function createConsumedThingFromNativeConsumedThing(
  thing: ConsumedThing,
): IConsumedThing {
  const readProperty$$ = <GValue>(
    propertyName: string,
    options?: InteractionOptions,
  ): IObservable<IDefaultNotificationsUnion<IInteractionOutput<GValue>>> => {
    return fromPromiseFactory(() => {
      return thing.readProperty(propertyName, options)
        .then((interactionOutput: InteractionOutput): IInteractionOutput<GValue> => {
          return createInteractionOutputFromNativeInteractionOutput<GValue>(interactionOutput);
        });
    });
  };

  const writeProperty = (
    propertyName: string,
    value: IInteractionInput,
    options?: InteractionOptions,
  ): IObservable<IDefaultNotificationsUnion<void>> => {
    if (isMaybeObservable<IDefaultNotificationsUnion<DataSchemaValue>>(value)) {
      value = toReadableStream(value);
    }
    return fromPromiseFactory(() => {
      return thing.writeProperty(propertyName, value, options);
    });
  };

  // const $$writeProperty = <GValue>(
  //   propertyName: string,
  //   onError: () => any,
  //   options?: InteractionOptions,
  // ): IObserver<GValue> => {
  //   return fromPromiseFactory(() => {
  //     return thing.writeProperty(propertyName, value, options);
  //   });
  // };

  return {
    readProperty$$,
    writeProperty,
  };
}
