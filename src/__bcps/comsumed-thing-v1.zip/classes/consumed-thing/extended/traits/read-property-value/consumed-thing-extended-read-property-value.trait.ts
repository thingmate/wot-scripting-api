import { IConsumedThingExtendedReadPropertyValueFunction } from './consumed-thing-extended-read-property-value.function-definition';

export interface IConsumedThingExtendedReadPropertyValueTrait {
  readPropertyValue$$: IConsumedThingExtendedReadPropertyValueFunction;
}
