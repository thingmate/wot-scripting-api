import { fulfilled$$, IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { InteractionOptions } from 'wot-typescript-definitions';
import { IInteractionOutput } from '../../../../../interaction-output/interaction-output.trait-collection';
import { IConsumedThingReadPropertyTrait } from '../../../../traits/read-property/consumed-thing-read-property.trait';
import { IConsumedThingExtendedReadPropertyValueFunction } from '../consumed-thing-extended-read-property-value.function-definition';

export interface ICreateConsumedThingExtendedReadPropertyValueFunctionUsing$ReadProperty$Options extends // traits
  IConsumedThingReadPropertyTrait
//
{
}


export function createConsumedThingExtendedReadPropertyValueFunctionUsing$ReadProperty$(
  {
    readProperty$$,
  }: ICreateConsumedThingExtendedReadPropertyValueFunctionUsing$ReadProperty$Options,
): IConsumedThingExtendedReadPropertyValueFunction {
  return <GValue> (
    propertyName: string,
    options?: InteractionOptions,
  ): IObservable<IDefaultNotificationsUnion<GValue>> => {
    return fulfilled$$(readProperty$$<GValue>(propertyName, options), (interactionOutput: IInteractionOutput<GValue>): IObservable<IDefaultNotificationsUnion<GValue>> => {
      return interactionOutput.value$;
    });
  };
}
