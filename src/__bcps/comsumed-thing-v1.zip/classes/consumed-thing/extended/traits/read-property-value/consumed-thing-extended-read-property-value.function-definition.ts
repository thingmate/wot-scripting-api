import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { InteractionOptions } from 'wot-typescript-definitions';

export interface IConsumedThingExtendedReadPropertyValueFunction {
  <GValue>(
    propertyName: string,
    options?: InteractionOptions,
  ): IObservable<IDefaultNotificationsUnion<GValue>>;
}
