import { ConsumedThing } from 'wot-typescript-definitions';
import { createConsumedThingFromNativeConsumedThing } from '../../implementations/create-consumed-thing-from-native-consumed-thing';
import { IConsumedThingExtended } from '../comsumed-thing-extended.trait-collection';
import {
  createConsumedThingExtendedReadPropertyValueFunctionUsing$ReadProperty$,
} from '../traits/read-property-value/derived/consumed-thing-extended-read-property-value-function.create.using-read-property';

export function createConsumedThingExtendedFromNativeConsumedThing(
  thing: ConsumedThing,
): IConsumedThingExtended {
  const {
    readProperty$$,
    writeProperty,
  } = createConsumedThingFromNativeConsumedThing(thing);

  const readPropertyValue$$ = createConsumedThingExtendedReadPropertyValueFunctionUsing$ReadProperty$({
    readProperty$$,
  });

  return {
    readProperty$$,
    readPropertyValue$$,
    writeProperty,
  };
}
