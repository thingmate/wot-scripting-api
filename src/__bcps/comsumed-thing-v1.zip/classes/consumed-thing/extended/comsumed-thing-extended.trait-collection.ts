import { IConsumedThing } from '../comsumed-thing.trait-collection';
import {
  IConsumedThingExtendedReadPropertyValueTrait
} from './traits/read-property-value/consumed-thing-extended-read-property-value.trait';

export interface IConsumedThingExtended extends IConsumedThing, // traits
  IConsumedThingExtendedReadPropertyValueTrait
//
{

}
