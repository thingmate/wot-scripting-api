import { IConsumedThingReadPropertyTrait } from './traits/read-property/consumed-thing-read-property.trait';
import { IConsumedThingWritePropertyTrait } from './traits/write-property/consumed-thing-write-property.trait';

export interface IConsumedThing extends // traits
  IConsumedThingReadPropertyTrait,
  IConsumedThingWritePropertyTrait
//
{

}
