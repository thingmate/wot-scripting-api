import {
  createErrorNotification,
  createNextNotification,
  IErrorNotification,
  INextNotification,
  IObservable,
  IObserver,
  IUnsubscribe,
} from '@lirx/core';
import { ConsumedThing, InteractionOutput, Subscription } from 'wot-typescript-definitions';

export type IConsumedThingObservableNotifications<GValue> =
  | INextNotification<GValue>
  | IErrorNotification
  ;

export type IConsumedThingObservableMode =
  | 'property'
  | 'event'
  ;


export function consumedThingObservableModeToMethodeName(
  mode: IConsumedThingObservableMode,
): string {
  switch (mode) {
    case 'property':
      return 'observeProperty';
    case 'event':
      return 'subscribeEvent';
    default:
      throw new TypeError(`Invalid mode: ${mode}`);
  }
}

export function createConsumedThingObservable<GValue>(
  thing: ConsumedThing,
  name: string,
  mode: IConsumedThingObservableMode,
): IObservable<IConsumedThingObservableNotifications<GValue>> {
  const methodName: string = consumedThingObservableModeToMethodeName(mode);
  return (emit: IObserver<IConsumedThingObservableNotifications<GValue>>): IUnsubscribe => {
    let running: boolean = true;
    let subscription: Subscription;

    const end = (): void => {
      running = false;
      if (subscription !== void 0) {
        subscription.stop();
      }
    };

    const next = (value: GValue): void => {
      if (running) {
        emit(createNextNotification<GValue>(value));
      }
    };

    const error = (error: any): void => {
      if (running) {
        emit(createErrorNotification<any>(error));
      }
    };

    const criticalError = (error: any): void => {
      if (running) {
        end();
        emit(createErrorNotification<any>(error));
      }
    };

    (thing[methodName] as typeof thing.observeProperty)(
      name,
      (data: InteractionOutput): void => {
        // TODO support stream ?
        (data.value() as Promise<GValue>)
          .then(
            next,
            error,
          );
      },
      error,
    )
      .then(
        (_subscription: Subscription): void => {
          subscription = _subscription;
          if (!running) {
            subscription.stop();
          }
        },
        criticalError,
      );

    return (): void => {
      if (running) {
        end();
      }
    };
  };
}
