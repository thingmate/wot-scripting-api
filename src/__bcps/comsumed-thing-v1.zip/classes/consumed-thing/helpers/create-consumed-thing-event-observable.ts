import { IObservable } from '@lirx/core';
import { ConsumedThing } from 'wot-typescript-definitions';
import { createConsumedThingObservable, IConsumedThingObservableNotifications } from './create-consumed-thing-observable';

export type IConsumedThingEventObservableNotifications<GValue> = IConsumedThingObservableNotifications<GValue>;

export function createConsumedThingEventObservable<GValue>(
  thing: ConsumedThing,
  name: string,
): IObservable<IConsumedThingEventObservableNotifications<GValue>> {
  return createConsumedThingObservable<GValue>(
    thing,
    name,
    'event',
  );
}
