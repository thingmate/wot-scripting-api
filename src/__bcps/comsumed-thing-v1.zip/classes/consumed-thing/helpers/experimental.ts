import { fromPromiseFactory, IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { ConsumedThing, InteractionOptions, InteractionOutput } from 'wot-typescript-definitions';
import { IAbortablePromiseOptions, IPromise, makePromiseAbortable } from '@lirx/promise';

export interface IAbortableInteractionOptions extends InteractionOptions, IAbortablePromiseOptions {

}

export function readConsumedThingPropertyValue<GValue>(
  thing: ConsumedThing,
  propertyName: string,
  options?: IAbortableInteractionOptions,
): IPromise<GValue> {
  return makePromiseAbortable<InteractionOutput>(thing.readProperty(propertyName, options))
    .then((output: InteractionOutput): Promise<GValue> => {
      return makePromiseAbortable<GValue>(output.value() as IPromise<GValue>, options);
    });
}

export function createReadConsumedThingPropertyObservable(
  thing: ConsumedThing,
  propertyName: string,
  options?: IAbortableInteractionOptions,
): IObservable<IDefaultNotificationsUnion<InteractionOutput>> {
  return fromPromiseFactory((signal: AbortSignal) => {
    return thing.readProperty(propertyName, options);
  }, options);
}


// export function createReadConsumedThingPropertyValueObservable<GValue>(
//   thing: ConsumedThing,
//   propertyName: string,
//   options?: IAbortableInteractionOptions,
// ): IObservable<IDefaultNotificationsUnion<GValue>> {
//   return fromPromiseFactory((signal: AbortSignal) => {
//     return thing.readProperty(propertyName, options);
//   }, options);
// }
