import { IObservable } from '@lirx/core';
import { ConsumedThing } from 'wot-typescript-definitions';
import { createConsumedThingObservable, IConsumedThingObservableNotifications } from './create-consumed-thing-observable';

export type IConsumedThingPropertyObservableNotifications<GValue> = IConsumedThingObservableNotifications<GValue>;

export function createConsumedThingPropertyObservable<GValue>(
  thing: ConsumedThing,
  name: string,
): IObservable<IConsumedThingPropertyObservableNotifications<GValue>> {
  return createConsumedThingObservable<GValue>(
    thing,
    name,
    'property',
  );
}
