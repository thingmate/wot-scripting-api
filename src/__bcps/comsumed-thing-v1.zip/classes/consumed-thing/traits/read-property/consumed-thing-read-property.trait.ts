import { IConsumedThingReadPropertyFunction } from './consumed-thing-read-property.function-definition';

export interface IConsumedThingReadPropertyTrait {
  readProperty$$: IConsumedThingReadPropertyFunction;
}
