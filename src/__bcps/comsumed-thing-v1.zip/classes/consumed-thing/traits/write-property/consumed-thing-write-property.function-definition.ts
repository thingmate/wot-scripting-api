import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';
import { InteractionOptions } from 'wot-typescript-definitions';
import { IInteractionInput } from '../../../interaction-input/interaction-input.type';

export interface IConsumedThingWritePropertyFunction {
  (
    propertyName: string,
    value: IInteractionInput,
    options?: InteractionOptions,
  ): IObservable<IDefaultNotificationsUnion<void>>;
}
