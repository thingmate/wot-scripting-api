import { IConsumedThingWritePropertyFunction } from './consumed-thing-write-property.function-definition';

export interface IConsumedThingWritePropertyTrait {
  writeProperty: IConsumedThingWritePropertyFunction;
}
