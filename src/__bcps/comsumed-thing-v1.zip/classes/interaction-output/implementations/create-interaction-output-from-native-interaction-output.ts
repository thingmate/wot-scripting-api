import { fromPromiseFactory, fromReadableStream, defer } from '@lirx/core';
import { InteractionOutput } from 'wot-typescript-definitions';
import { IInteractionOutput } from '../interaction-output.trait-collection';

export function createInteractionOutputFromNativeInteractionOutput<GValue>(
  interactionOutput: InteractionOutput,
): IInteractionOutput<GValue> {
  const stream$ = defer(() => fromReadableStream(interactionOutput.data!));

  const value$ = fromPromiseFactory(() => {
    return interactionOutput.value() as Promise<GValue>;
  });

  return {
    stream$,
    value$,
  };
}
