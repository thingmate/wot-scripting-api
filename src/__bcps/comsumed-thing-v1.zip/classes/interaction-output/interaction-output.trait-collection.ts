import { IInteractionOutputStreamTrait } from './traits/stream/interaction-output-stream.trait';
import { IInteractionOutputValueTrait } from './traits/value/interaction-output-value.trait';

export interface IInteractionOutput<GValue> extends // traits
  IInteractionOutputStreamTrait<GValue>,
  IInteractionOutputValueTrait<GValue>
//
{

}
