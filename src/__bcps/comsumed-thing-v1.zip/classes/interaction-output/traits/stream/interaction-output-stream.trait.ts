import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export interface IInteractionOutputStreamTrait<GValue> {
  readonly stream$: IObservable<IDefaultNotificationsUnion<GValue>>;
}
