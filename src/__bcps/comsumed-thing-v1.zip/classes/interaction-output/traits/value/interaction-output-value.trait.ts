import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export interface IInteractionOutputValueTrait<GValue> {
  readonly value$: IObservable<IDefaultNotificationsUnion<GValue>>;
}
