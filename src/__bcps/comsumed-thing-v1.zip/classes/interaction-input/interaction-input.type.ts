import { DataSchemaValue, InteractionInput } from 'wot-typescript-definitions';
import { IDefaultNotificationsUnion, IObservable } from '@lirx/core';

export type IInteractionInput =
  | IObservable<IDefaultNotificationsUnion<DataSchemaValue>>
  | InteractionInput
;
