import { IConsumedThingGetActionTrait } from './traits/get-action/consumed-thing-get-action.trait';
import { IConsumedThingGetEventTrait } from './traits/get-event/consumed-thing-get-event.trait';
import { IConsumedThingGetPropertyTrait } from './traits/get-property/consumed-thing-get-property.trait';
import { IConsumedThingGetThingDescriptionTrait } from './traits/get-thing-description/consumed-thing-get-thing-description.trait';

export interface IConsumedThing extends // traits
  IConsumedThingGetThingDescriptionTrait,
  IConsumedThingGetPropertyTrait,
  IConsumedThingGetActionTrait,
  IConsumedThingGetEventTrait
//
{

}
