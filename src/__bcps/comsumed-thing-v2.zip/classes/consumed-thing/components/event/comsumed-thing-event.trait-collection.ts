import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingEventGetNameTrait } from './traits/get-name/consumed-thing-event-get-name.trait';
import { IConsumedThingEventObservableTrait } from './traits/observable/consumed-thing-event-observable.trait';

export interface IConsumedThingEvent<GName extends string, GValue extends DataSchemaValue> extends // traits
  IConsumedThingEventGetNameTrait<GName>,
  IConsumedThingEventObservableTrait<GValue>
//
{

}
