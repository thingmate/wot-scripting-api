import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingEventObservableFunction } from './consumed-thing-event-observable.function-definition';

export interface IConsumedThingEventObservableTrait<GValue extends DataSchemaValue> {
  observable: IConsumedThingEventObservableFunction<GValue>;
}
