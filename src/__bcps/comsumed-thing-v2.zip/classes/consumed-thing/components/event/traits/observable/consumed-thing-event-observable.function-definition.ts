import { IErrorNotification, INextNotification, IObservable } from '@lirx/core';
import { DataSchemaValue, InteractionOptions } from 'wot-typescript-definitions';

export interface IConsumedThingEventObservableOptions extends InteractionOptions {

}

export type IConsumedThingEventObservableNotifications<GValue> =
  | INextNotification<GValue>
  | IErrorNotification
  ;

export interface IConsumedThingEventObservableFunction<GValue extends DataSchemaValue> {
  (
    options?: IConsumedThingEventObservableOptions,
  ): IObservable<IConsumedThingEventObservableNotifications<GValue>>;
}
