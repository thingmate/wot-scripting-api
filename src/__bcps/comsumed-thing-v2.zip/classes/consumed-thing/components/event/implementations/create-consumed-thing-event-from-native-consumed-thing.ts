import { IObservable } from '@lirx/core';
import { EventElement } from 'wot-thing-description-types';
import { ConsumedThing, DataSchemaValue, ThingDescription } from 'wot-typescript-definitions';
import { createConsumedThingEventObservable } from '../../../helpers/create-consumed-thing-event-observable';
import { IConsumedThingEvent } from '../comsumed-thing-event.trait-collection';
import {
  IConsumedThingEventObservableNotifications,
  IConsumedThingEventObservableOptions,
} from '../traits/observable/consumed-thing-event-observable.function-definition';

// https://www.w3.org/TR/2018/WD-wot-scripting-api-20181129/#dom-thingevent

export function createConsumedThingEventFromNativeConsumedThing<GName extends string, GValue extends DataSchemaValue>(
  thing: ConsumedThing,
  name: GName,
): IConsumedThingEvent<GName, GValue> {

  const td: ThingDescription = thing.getThingDescription();

  let eventElement: EventElement;

  if (td.events === void 0) {
    throw new Error(`Missing td.events`);
  }

  if (td.events[name] === void 0) {
    throw new Error(`Missing td.events[${name}]`);
  } else {
    eventElement = td.events[name];
  }

  const getName = (): GName => {
    return name;
  };

  const observable = (
    options?: IConsumedThingEventObservableOptions,
  ): IObservable<IConsumedThingEventObservableNotifications<GValue>> => {
    return createConsumedThingEventObservable<GValue>(thing, name, options);
  };

  return {
    getName,
    observable,
  };
}
