import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingPropertyGetNameTrait } from './traits/get-name/consumed-thing-property-get-name.trait';
import { IConsumedThingPropertyGetTypeTrait } from './traits/get-type/consumed-thing-property-get-type.trait';
import { IConsumedThingPropertyIsWritableTrait } from './traits/is-writable/consumed-thing-property-is-writable.trait';
import { IConsumedThingPropertyObservableTrait } from './traits/observable/consumed-thing-property-observable.trait';
import { IConsumedThingPropertyReadTrait } from './traits/read/consumed-thing-property-read.trait';
import { IConsumedThingPropertyWriteTrait } from './traits/write/consumed-thing-property-write.trait';

export interface IConsumedThingProperty<GName extends string, GValue extends DataSchemaValue> extends // traits
  IConsumedThingPropertyGetNameTrait<GName>,
  IConsumedThingPropertyGetTypeTrait,
  IConsumedThingPropertyIsWritableTrait,
  IConsumedThingPropertyReadTrait<GValue>,
  IConsumedThingPropertyWriteTrait<GValue>,
  IConsumedThingPropertyObservableTrait<GValue>
//
{

}
