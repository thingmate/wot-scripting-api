import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingPropertyObservableFunction } from './consumed-thing-property-observable.function-definition';

export interface IConsumedThingPropertyObservableTrait<GValue extends DataSchemaValue> {
  observable: IConsumedThingPropertyObservableFunction<GValue>;
}
