import { DataSchemaType } from 'wot-thing-description-types';

export type IConsumedThingPropertyType = DataSchemaType;

export interface IConsumedThingPropertyGetTypeFunction {
  (): IConsumedThingPropertyType;
}
