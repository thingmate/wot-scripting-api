import { IErrorNotification, INextNotification, IObservable } from '@lirx/core';
import { DataSchemaValue, InteractionOptions } from 'wot-typescript-definitions';

export interface IConsumedThingPropertyObservableOptions extends InteractionOptions {

}

export type IConsumedThingPropertyObservableNotifications<GValue> =
  | INextNotification<GValue>
  | IErrorNotification
  ;

export interface IConsumedThingPropertyObservableFunction<GValue extends DataSchemaValue> {
  (
    options?: IConsumedThingPropertyObservableOptions,
  ): IObservable<IConsumedThingPropertyObservableNotifications<GValue>>;
}
