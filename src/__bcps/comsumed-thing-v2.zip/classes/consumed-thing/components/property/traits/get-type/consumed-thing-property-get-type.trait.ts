import { IConsumedThingPropertyGetTypeFunction } from './consumed-thing-property-get-type.function-definition';

export interface IConsumedThingPropertyGetTypeTrait {
  getType: IConsumedThingPropertyGetTypeFunction;
}
