export interface IConsumedThingPropertyIsWritableFunction {
  (): boolean;
}
