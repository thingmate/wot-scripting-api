import { IConsumedThingPropertyIsWritableFunction } from './consumed-thing-property-is-writable.function-definition';

export interface IConsumedThingPropertyIsWritableTrait {
  isWritable: IConsumedThingPropertyIsWritableFunction;
}
