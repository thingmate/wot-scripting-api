import { IObservable } from '@lirx/core';
import { IAbortablePromiseOptions, IPromise, makePromiseAbortable } from '@lirx/promise';
import { PropertyElement } from 'wot-thing-description-types';
import { ConsumedThing, DataSchemaValue, InteractionOutput, ThingDescription } from 'wot-typescript-definitions';
import { createConsumedThingPropertyObservable } from '../../../helpers/create-consumed-thing-property-observable';
import { IConsumedThingProperty } from '../comsumed-thing-property.trait-collection';
import { IConsumedThingPropertyType } from '../traits/get-type/consumed-thing-property-get-type.function-definition';
import {
  IConsumedThingPropertyObservableNotifications,
  IConsumedThingPropertyObservableOptions,
} from '../traits/observable/consumed-thing-property-observable.function-definition';
import { IConsumedThingPropertyReadOptions } from '../traits/read/consumed-thing-property-read.function-definition';
import { IConsumedThingPropertyWriteOptions } from '../traits/write/consumed-thing-property-write.function-definition';

// https://www.w3.org/TR/2018/WD-wot-scripting-api-20181129/#dom-thingproperty

export function createConsumedThingPropertyFromNativeConsumedThing<GName extends string, GValue extends DataSchemaValue>(
  thing: ConsumedThing,
  name: GName,
): IConsumedThingProperty<GName, GValue> {

  const td: ThingDescription = thing.getThingDescription();

  let propertyElement: PropertyElement;

  if (td.properties === void 0) {
    throw new Error(`Missing td.properties`);
  }

  if (td.properties[name] === void 0) {
    throw new Error(`Missing td.properties[${name}]`);
  } else {
    propertyElement = td.properties[name];
  }

  const getName = (): GName => {
    return name;
  };

  const getType = (): IConsumedThingPropertyType => {
    return propertyElement.type!;
  };

  const isWritable = (): boolean => {
    return !propertyElement.readOnly!;
  };

  const isReadable = (): boolean => {
    return !propertyElement.writeOnly!;
  };

  const isObservable = (): boolean => {
    return propertyElement.observable!;
  };

  const read = (
    options?: IConsumedThingPropertyReadOptions,
  ): IPromise<GValue> => {
    return makePromiseAbortable<InteractionOutput>(thing.readProperty(name, options), options)
      .then((interactionOutput: InteractionOutput): IPromise<GValue> => {
        return makePromiseAbortable<GValue>(interactionOutput.value() as IPromise<GValue>, options);
      });
  };

  // const readAsStream$$ = (
  //   options?: IAbortablePromiseOptions,
  // ): IObservable<IDefaultNotificationsUnion<GValue>> => {
  //   return fromPromiseFactorymakePromiseAbortable<InteractionOutput>(thing.readProperty(name), options)
  //     .then((interactionOutput: InteractionOutput): IPromise<GValue> => {
  //       return makePromiseAbortable<GValue>(interactionOutput.value() as IPromise<GValue>, options);
  //     });
  // };

  const write = (
    value: GValue,
    options?: IConsumedThingPropertyWriteOptions,
  ): IPromise<void> => {
    return makePromiseAbortable<void>(thing.writeProperty(name, value, options), options);
  };

  const observable = (
    options?: IConsumedThingPropertyObservableOptions,
  ): IObservable<IConsumedThingPropertyObservableNotifications<GValue>> => {
    return createConsumedThingPropertyObservable<GValue>(thing, name, options);
  };

  return {
    getName,
    getType,
    isWritable,
    read,
    write,
    observable,
  };
}
