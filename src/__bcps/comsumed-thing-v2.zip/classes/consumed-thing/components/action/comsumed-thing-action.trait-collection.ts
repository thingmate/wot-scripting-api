import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingActionGetNameTrait } from './traits/get-name/consumed-thing-action-get-name.trait';
import { IConsumedThingActionInvokeTrait } from './traits/invoke/consumed-thing-action-invoke.trait';

export interface IConsumedThingAction<GName extends string, GIn extends DataSchemaValue, GOut extends DataSchemaValue> extends // traits
  IConsumedThingActionGetNameTrait<GName>,
  IConsumedThingActionInvokeTrait<GIn, GOut>
//
{

}
