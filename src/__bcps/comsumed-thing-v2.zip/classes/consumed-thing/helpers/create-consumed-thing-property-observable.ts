import { IObservable } from '@lirx/core';
import { ConsumedThing, InteractionOptions } from 'wot-typescript-definitions';
import { createConsumedThingObservable, IConsumedThingObservableNotifications } from './create-consumed-thing-observable';

export type IConsumedThingPropertyObservableNotifications<GValue> = IConsumedThingObservableNotifications<GValue>;

export function createConsumedThingPropertyObservable<GValue>(
  thing: ConsumedThing,
  name: string,
  options?: InteractionOptions,
): IObservable<IConsumedThingPropertyObservableNotifications<GValue>> {
  return createConsumedThingObservable<GValue>(
    thing,
    name,
    'property',
    options,
  );
}
