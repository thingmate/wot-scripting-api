import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingAction } from '../../components/action/comsumed-thing-action.trait-collection';

export interface IConsumedThingGetActionFunction {
  <GName extends string, GIn extends DataSchemaValue, GOut extends DataSchemaValue>(
    actionName: GName,
  ): IConsumedThingAction<GName, GIn, GOut>;
}
