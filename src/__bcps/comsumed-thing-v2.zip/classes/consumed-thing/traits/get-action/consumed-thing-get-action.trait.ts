import { IConsumedThingGetActionFunction } from './consumed-thing-get-action.function-definition';

export interface IConsumedThingGetActionTrait {
  getAction: IConsumedThingGetActionFunction;
}
