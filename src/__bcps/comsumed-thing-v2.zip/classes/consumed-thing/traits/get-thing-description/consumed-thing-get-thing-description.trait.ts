import { IConsumedThingGetThingDescriptionFunction } from './consumed-thing-get-thing-description.function-definition';

export interface IConsumedThingGetThingDescriptionTrait {
  getThingDescription: IConsumedThingGetThingDescriptionFunction;
}
