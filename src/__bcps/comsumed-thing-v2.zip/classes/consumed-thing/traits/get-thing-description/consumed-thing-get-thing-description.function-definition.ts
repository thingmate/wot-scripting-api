import { ThingDescription } from 'wot-typescript-definitions';

export interface IConsumedThingGetThingDescriptionFunction {
  (): ThingDescription;
}
