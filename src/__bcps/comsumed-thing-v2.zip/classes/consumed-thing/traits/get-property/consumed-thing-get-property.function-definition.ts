import { DataSchemaValue } from 'wot-typescript-definitions';
import { IConsumedThingProperty } from '../../components/property/comsumed-thing-property.trait-collection';

export interface IConsumedThingGetPropertyFunction {
  <GName extends string, GValue extends DataSchemaValue>(
    propertyName: GName,
  ): IConsumedThingProperty<GName, GValue>;
}
