import { IConsumedThingGetPropertyFunction } from './consumed-thing-get-property.function-definition';

export interface IConsumedThingGetPropertyTrait {
  getProperty: IConsumedThingGetPropertyFunction;
}
