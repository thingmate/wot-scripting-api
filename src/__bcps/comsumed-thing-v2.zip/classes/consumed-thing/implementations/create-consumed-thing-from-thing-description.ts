import { ThingDescription } from 'wot-typescript-definitions';
import { IWoT } from '../../../run-wot-context';
import { IConsumedThing } from '../comsumed-thing.trait-collection';
import { createConsumedThingFromNativeConsumedThing } from './create-consumed-thing-from-native-consumed-thing';

export function createConsumedThingFromThingDescription(
  WoT: IWoT,
  td: ThingDescription,
): Promise<IConsumedThing> {
  return WoT.consume(td)
    .then(createConsumedThingFromNativeConsumedThing);
}
