import { ConsumedThing, DataSchemaValue, ThingDescription } from 'wot-typescript-definitions';
import { IConsumedThingAction } from '../components/action/comsumed-thing-action.trait-collection';
import {
  createConsumedThingActionFromNativeConsumedThing
} from '../components/action/implementations/create-consumed-thing-action-from-native-consumed-thing';
import { IConsumedThingEvent } from '../components/event/comsumed-thing-event.trait-collection';
import {
  createConsumedThingEventFromNativeConsumedThing
} from '../components/event/implementations/create-consumed-thing-event-from-native-consumed-thing';

import { IConsumedThingProperty } from '../components/property/comsumed-thing-property.trait-collection';
import {
  createConsumedThingPropertyFromNativeConsumedThing,
} from '../components/property/implementations/create-consumed-thing-property-from-native-consumed-thing';
import { IConsumedThing } from '../comsumed-thing.trait-collection';

export function createConsumedThingFromNativeConsumedThing(
  thing: ConsumedThing,
): IConsumedThing {
  const getThingDescription = (): ThingDescription => {
    return thing.getThingDescription();
  };

  const getProperty = <GName extends string, GValue extends DataSchemaValue>(
    name: GName,
  ): IConsumedThingProperty<GName, GValue> => {
    return createConsumedThingPropertyFromNativeConsumedThing<GName, GValue>(thing, name);
  };

  const getAction = <GName extends string, GIn extends DataSchemaValue, GOut extends DataSchemaValue>(
    name: GName,
  ): IConsumedThingAction<GName, GIn, GOut> => {
    return createConsumedThingActionFromNativeConsumedThing<GName, GIn, GOut>(thing, name);
  };

  const getEvent = <GName extends string, GValue extends DataSchemaValue>(
    name: GName,
  ): IConsumedThingEvent<GName, GValue> => {
    return createConsumedThingEventFromNativeConsumedThing<GName, GValue>(thing, name);
  };

  return {
    getThingDescription,
    getProperty,
    getAction,
    getEvent,
  };
}
