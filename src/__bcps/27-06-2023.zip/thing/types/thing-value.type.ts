export type IThingValue =
  | null
  | boolean
  | number
  | string
  | object
  | IThingValue[]
  ;
