import { IToggleOnOffStateThingAction } from './toggle-on-off-state-thing-action.type';

export interface IHavingToggleOnOffStateThingAction {
  toggle: IToggleOnOffStateThingAction;
}
