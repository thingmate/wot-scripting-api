import { Thing } from '../../../thing/thing.class';
import { ISmartPlugConfig } from './smart-plug-config.type';

export type ISmartPlugThing = Thing<ISmartPlugConfig>;

