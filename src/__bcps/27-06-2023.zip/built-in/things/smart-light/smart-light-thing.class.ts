import { Thing } from '../../../thing/thing.class';
import { ISmartLightConfig } from './smart-light-config.type';

export class SmartLightThing extends Thing<ISmartLightConfig> {

}
