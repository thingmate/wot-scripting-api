import { ThingProperty } from '../../../thing/property/thing-property.class';

export type IOnlineThingProperty = ThingProperty<boolean>;

