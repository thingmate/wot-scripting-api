import { IColorThingProperty } from './color-thing-property.type';

export interface IHavingColorThingProperty {
  color: IColorThingProperty;
}
