import { IOnOffStateThingProperty } from './on-off-state-thing-property.type';

export interface IHavingOnOffStateThingProperty {
  state: IOnOffStateThingProperty;
}
