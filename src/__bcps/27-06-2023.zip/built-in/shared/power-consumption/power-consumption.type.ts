export interface IPowerConsumption {
  current: number;
  voltage: number;
  power: number;
}
