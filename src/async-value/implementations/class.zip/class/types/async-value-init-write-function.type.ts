import { Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueInitWriteFunction<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
