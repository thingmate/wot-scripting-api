import { Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueInitObserveSinkFunction<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
