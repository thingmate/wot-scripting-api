import { IAsyncTaskConstraint } from '@lirx/async-task';
import { IAsyncValueInitReadFunction } from './async-value-init-read-function.type';
import { IAsyncValueInitWriteFunction } from './async-value-init-write-function.type';
import { IAsyncValueInitObserveFunction } from './async-value-init-observe-function.type';

export interface IAsyncValueInitOptions<GValue extends IAsyncTaskConstraint<GValue>> {
  readonly read: IAsyncValueInitReadFunction<GValue>;
  readonly write?: IAsyncValueInitWriteFunction<GValue> | undefined;
  readonly observe?: IAsyncValueInitObserveFunction<GValue> | undefined;
}
