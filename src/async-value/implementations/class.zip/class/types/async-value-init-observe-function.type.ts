import { IAsyncValueInitObserveSinkFunction } from './async-value-init-observe-sink-function.type';
import { Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueInitObserveFunction<GValue> {
  (
    sink: IAsyncValueInitObserveSinkFunction<GValue>,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
