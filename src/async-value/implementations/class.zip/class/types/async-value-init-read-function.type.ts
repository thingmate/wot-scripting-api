import { IAsyncTaskConstraint, Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IAsyncValueInitReadFunction<GValue extends IAsyncTaskConstraint<GValue>> {
  (
    abortable: Abortable,
  ): IAsyncTaskInput<GValue>;
}
