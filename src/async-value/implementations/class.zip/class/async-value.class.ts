import { IAsyncTaskConstraint, Abortable, AsyncTask, IAsyncTaskInput, asyncTimeout } from '@lirx/async-task';
import { IAsyncValueInitReadFunction } from './types/async-value-init-read-function.type';
import { IAsyncValueInitWriteFunction } from './types/async-value-init-write-function.type';
import { IAsyncValueInitObserveSinkFunction } from './types/async-value-init-observe-sink-function.type';
import { IAsyncValueInitObserveFunction } from './types/async-value-init-observe-function.type';
import { IAsyncValueInitOptions } from './types/async-value-init-options.type';

export class AsyncValue<GValue extends IAsyncTaskConstraint<GValue>> {
  readonly #read: IAsyncValueInitReadFunction<GValue>;
  readonly #write: IAsyncValueInitWriteFunction<GValue> | undefined;
  readonly #observe: IAsyncValueInitObserveFunction<GValue> | undefined;

  constructor(
    {
      read,
      write,
      observe,
    }: IAsyncValueInitOptions<GValue>,
  ) {
    this.#read = read;
    this.#write = write;
    this.#observe = observe;
  }

  read(
    abortable: Abortable,
  ): AsyncTask<GValue> {
    return AsyncTask.fromFactory<GValue>(this.#read, abortable);
  }

  get writable(): boolean {
    return this.#write !== void 0;
  }

  write(
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory<void>((abortable: Abortable): IAsyncTaskInput<void> => {
      if (this.#write === void 0) {
        throw new Error(`Non writable.`);
      } else {
        return this.#write(value, abortable);
      }
    }, abortable);
  }

  get observable(): boolean {
    return this.#observe !== void 0;
  }

  observe(
    sink: IAsyncValueInitObserveSinkFunction<GValue>,
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory<void>((abortable: Abortable): IAsyncTaskInput<void> => {
      if (this.#observe === void 0) {
        throw new Error(`Non observable.`);
      } else {
        return this.#observe(sink, abortable);
      }
    }, abortable);
  }

  spy(
    sink: IAsyncValueInitObserveSinkFunction<GValue>,
    period: number,
    abortable: Abortable,
  ): AsyncTask<void> {
    const loop = (
      abortable: Abortable,
    ): AsyncTask<void> => {
      const start: number = Date.now();
      return this.read(abortable)
        .successful((
          value: GValue,
          abortable: Abortable,
        ): IAsyncTaskInput<void> => {
          return sink(value, abortable);
        })
        .successful((
          _,
          abortable: Abortable,
        ): AsyncTask<void> => {
          return asyncTimeout(
            Math.max(0, period - (Date.now() - start)),
            abortable,
          );
        })
        .successful((
          _,
          abortable: Abortable,
        ): AsyncTask<void> => {
          return loop(abortable);
        });
    };

    return loop(abortable);
  }
}

