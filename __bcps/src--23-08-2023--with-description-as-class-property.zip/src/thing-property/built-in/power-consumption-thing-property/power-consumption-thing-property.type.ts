import { IThingProperty } from '../../thing-property.type';
import { IPowerConsumption } from './type/power-consumption.type';

export type IPowerConsumptionThingProperty = IThingProperty<IPowerConsumption>;

