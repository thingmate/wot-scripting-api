import { IPowerConsumptionThingProperty } from './power-consumption-thing-property.type';

export interface IHavingPowerConsumptionThingProperty {
  consumption: IPowerConsumptionThingProperty;
}
