import { IThingProperty } from '../../thing-property.type';

export type IOnlineThingProperty = IThingProperty<boolean>;

