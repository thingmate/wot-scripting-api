import { IThingProperty } from '../../thing-property.type';
import { IOnOff } from './type/on-off.type';

export type IOnOffThingProperty = IThingProperty<IOnOff>;

