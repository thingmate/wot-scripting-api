export interface IThingDescription {
  title: string;
}
