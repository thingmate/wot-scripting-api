import { Abortable, AsyncTask, IAsyncTaskFactory, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { toAsyncIterable } from '@lirx/core';
import { noop } from '@lirx/utils';
import { IGenericThing } from '../thing/thing.class';
import {
  IThingDiscoveryConsumerDiscoverFunction,
} from './methods/discover/thing-discovery-discover-function.type';
import { IThingDiscoveryInitOptions } from './thing-discovery-init-options.type';



export class ThingDiscovery<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {

  readonly #discover: IThingDiscoveryConsumerDiscoverFunction<GThing>;

  constructor(
    {
      discover,
    }: IThingDiscoveryInitOptions<GThing>,
  ) {
    let queue: AsyncTask<any> = AsyncTask.void(Abortable.never);

    this.#discover = (
      abortable: Abortable = Abortable.never,
    ): AsyncTask<IteratorResult<GThing>> => {
      return queue = queue
        .settled((_, abortable: Abortable) => discover(abortable), abortable);
    };
  }

  get discover(): IThingDiscoveryConsumerDiscoverFunction<GThing> {
    return this.#discover;
  }

  async* [Symbol.asyncIterator](): AsyncGenerator<GThing> {

  }
}
