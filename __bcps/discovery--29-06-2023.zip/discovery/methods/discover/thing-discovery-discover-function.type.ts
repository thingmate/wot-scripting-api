import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { IGenericThing } from '../../../thing/thing.class';

export interface IThingDiscoveryProducerDiscoverFunction<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  (
    abortable: Abortable,
  ): IAsyncTaskInput<GThing>;
}

export interface IThingDiscoveryConsumerDiscoverFunction<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
  (
    abortable?: Abortable,
  ): AsyncTask<GThing>;
}

// export interface IDiscoverFunctionPendingResult<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> {
//   done: false;
//   value: GThing;
// }

// export interface IDiscoverFunctionDoneResult {
//   done: true;
//   value: undefined;
// }
//
// export type IDiscoverFunctionResult<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> =
//   | IDiscoverFunctionPendingResult<GThing>
//   | IDiscoverFunctionDoneResult
//   ;
//
//
// export const DISCOVER_FUNCTION_DONE_RESULT: IDiscoverFunctionDoneResult = {
//   done: true,
//   value: undefined,
// };
