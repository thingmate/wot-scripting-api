export interface IThingDescription {
  readonly title: string;
}
