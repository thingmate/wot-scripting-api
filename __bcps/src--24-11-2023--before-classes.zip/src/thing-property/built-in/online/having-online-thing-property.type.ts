import { IOnlineThingProperty } from './online-thing-property.type';

export interface IHavingOnlineThingProperty {
  readonly online: IOnlineThingProperty;
}
