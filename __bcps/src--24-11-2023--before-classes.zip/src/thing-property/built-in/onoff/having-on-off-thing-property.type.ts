import { IOnOffThingProperty } from './on-off-thing-property.type';

export interface IHavingOnOffThingProperty {
  readonly onoff: IOnOffThingProperty;
}
