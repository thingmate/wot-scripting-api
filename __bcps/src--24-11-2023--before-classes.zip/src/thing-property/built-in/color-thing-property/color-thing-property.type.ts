import { IThingProperty } from '../../thing-property.type';
import { IRGBCW } from './type/rgb-cw.type';

export type IColorThingProperty = IThingProperty<IRGBCW>;

