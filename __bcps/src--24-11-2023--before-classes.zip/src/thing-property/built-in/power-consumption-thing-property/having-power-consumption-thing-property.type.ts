import { IPowerConsumptionThingProperty } from './power-consumption-thing-property.type';

export interface IHavingPowerConsumptionThingProperty {
  readonly consumption: IPowerConsumptionThingProperty;
}
