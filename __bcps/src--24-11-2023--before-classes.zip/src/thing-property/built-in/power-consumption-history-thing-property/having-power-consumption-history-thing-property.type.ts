import { IPowerConsumptionHistoryThingProperty } from './power-consumption-history-thing-property.type';

export interface IHavingPowerConsumptionHistoryThingProperty {
  readonly consumptionHistory: IPowerConsumptionHistoryThingProperty;
}
