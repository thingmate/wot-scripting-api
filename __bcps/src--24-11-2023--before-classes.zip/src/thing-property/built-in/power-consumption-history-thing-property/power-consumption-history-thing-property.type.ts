import { IThingProperty } from '../../thing-property.type';
import { IPowerConsumptionHistory } from './type/power-consumption-history.type';

export type IPowerConsumptionHistoryThingProperty = IThingProperty<IPowerConsumptionHistory[]>;

