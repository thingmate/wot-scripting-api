import { IThingConfigActionsConstraint } from '../traits/get-action/thing-actions-config.type';
import { IThingConfigEventsConstraint } from '../traits/get-event/thing-events-config.type';
import { IThingConfigPropertiesConstraint } from '../traits/get-property/thing-properties-config.type';

export type IThingConfigConstraint<GThingConfig> =
  IThingConfigPropertiesConstraint<GThingConfig>
  & IThingConfigActionsConstraint<GThingConfig>
  & IThingConfigEventsConstraint<GThingConfig>
  ;

