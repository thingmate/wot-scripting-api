import { IThingConfigConstraint } from '../../types/thing-config.type';
import { IThingGetPropertyFunction } from './thing-get-property.function-definition';

export interface IThingGetPropertyTrait<GConfig extends IThingConfigConstraint<GConfig>> {
  getProperty: IThingGetPropertyFunction<GConfig>;
}
