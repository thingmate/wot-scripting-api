import { IThingConfigConstraint } from '../../types/thing-config.type';
import { InferThingPropertyFromName, InferThingPropertyNames } from './thing-properties-config.type';

export interface IThingGetPropertyFunction<GConfig extends IThingConfigConstraint<GConfig>> {
  <GName extends InferThingPropertyNames<GConfig>>(
    name: GName,
  ): InferThingPropertyFromName<GConfig, GName>;
}

