import { InferThingActionFromName, InferThingActionNames, IThingConfigActionsConstraint } from './thing-actions-config.type';

export interface IThingGetActionFunction<GConfig extends IThingConfigActionsConstraint<GConfig>> {
  <GName extends InferThingActionNames<GConfig>>(
    name: GName,
  ): InferThingActionFromName<GConfig, GName>;
}
