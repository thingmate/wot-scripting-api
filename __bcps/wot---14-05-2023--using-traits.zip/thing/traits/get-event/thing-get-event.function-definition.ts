import { InferThingEventFromName, InferThingEventNames, IThingConfigEventsConstraint } from './thing-events-config.type';

export interface IThingGetEventFunction<GConfig extends IThingConfigEventsConstraint<GConfig>> {
  <GName extends InferThingEventNames<GConfig>>(
    name: GName,
  ): InferThingEventFromName<GConfig, GName>;
}
