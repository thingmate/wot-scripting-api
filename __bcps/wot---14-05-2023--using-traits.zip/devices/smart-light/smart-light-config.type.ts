import { IHavingColorThingProperty } from '../shared/color/thing-config/color-thing-property.type';
import { IHavingOnOffStateThingProperty } from '../shared/on-off-state/thing-config/on-off-state-thing-property.type';
import { IHavingToggleOnOffStateThingAction } from '../shared/on-off-state/thing-config/toggle-on-off-state-thing-action.type';
import { IHavingPowerConsumptionThingProperty } from '../shared/power-consumption/thing-config/power-consumption-thing-property.type';

export interface ISmartLightConfigProperties extends //
  IHavingOnOffStateThingProperty,
  IHavingPowerConsumptionThingProperty,
  IHavingColorThingProperty
//
{
}

export interface ISmartLightConfigActions extends //
  IHavingToggleOnOffStateThingAction
//
{

}

export interface ISmartLightConfig {
  properties: ISmartLightConfigProperties;
  actions: ISmartLightConfigActions;
}
