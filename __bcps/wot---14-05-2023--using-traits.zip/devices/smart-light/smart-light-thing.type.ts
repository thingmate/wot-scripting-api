import { IThing } from '../../thing/thing.trait-collection';
import { ISmartLightConfig } from './smart-light-config.type';

export type ISmartLightThing = IThing<ISmartLightConfig>;

