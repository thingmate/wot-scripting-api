export type IOnOffState =
  | 'on'
  | 'off'
  ;
