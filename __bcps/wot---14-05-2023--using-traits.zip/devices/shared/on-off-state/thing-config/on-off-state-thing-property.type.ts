import { IThingProperty } from '../../../../thing/components/property/thing-property.trait-collection';
import { IOnOffState } from '../on-off-state.type';

export type IOnOffStateThingProperty = IThingProperty<IOnOffState>;

export interface IHavingOnOffStateThingProperty {
  state: IOnOffStateThingProperty;
}

export const ON_OFF_STATE_PROPERTY_TD = {
  state: {
    enum: ['on', 'off'],
  },
};
