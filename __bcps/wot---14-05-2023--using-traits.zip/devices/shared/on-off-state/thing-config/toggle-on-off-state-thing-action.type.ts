import { IThingAction } from '../../../../thing/components/action/thing-action.trait-collection';
import { IOnOffState } from '../on-off-state.type';

export type IToggleOnOffStateThingAction = IThingAction<IOnOffState | null, IOnOffState>;

export interface IHavingToggleOnOffStateThingAction {
  toggle: IToggleOnOffStateThingAction;
}

export const TOGGLE_ON_OFF_STATE_ACTION_TD = {
  toggle: {
    input: {
      enum: ['on', 'off'],
    },
    output: {
      enum: ['on', 'off'],
    },
  },
};
