import { IThingProperty } from '../../../../thing/components/property/thing-property.trait-collection';
import { IPowerConsumptionHistory } from '../power-consumption-history.type';

export type IPowerConsumptionHistoryThingProperty = IThingProperty<IPowerConsumptionHistory[]>;

export interface IHavingPowerConsumptionHistoryThingProperty {
  consumptionHistory: IPowerConsumptionHistoryThingProperty;
}

export const POWER_CONSUMPTION_HISTORY_PROPERTY_TD = {
  consumptionHistory: {
    type: 'array',
    items: {
      type: 'object',
      properties: {
        power: {
          type: 'number',
          unit: 'W',
        },
        start: {
          title: 'start date as timestamp in ms',
          type: 'number',
          unit: 'ms',
        },
        end: {
          title: 'end date as timestamp in ms',
          type: 'number',
          unit: 'ms',
        },
      },
    },
    readOnly: true,
  },
};
