export interface IColor {
  h: number; // hue [0, 1]
  s: number; // saturation [0, 1]
  l: number; // brightness [0, 1]
}
