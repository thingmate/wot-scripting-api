import { IThingProperty } from '../../../../thing/components/property/thing-property.trait-collection';
import { IColor } from '../color.type';

export type IColorThingProperty = IThingProperty<IColor>;

export interface IHavingColorThingProperty {
  color: IColorThingProperty;
}

export const COLOR_STATE_PROPERTY_TD = {
  state: {
    type: 'object',
    properties: {
      h: {
        title: 'hue',
        type: 'number',
      },
      s: {
        title: 'saturation',
        type: 'number',
      },
      l: {
        title: 'brightness',
        type: 'number',
      },
    },
  },
};
