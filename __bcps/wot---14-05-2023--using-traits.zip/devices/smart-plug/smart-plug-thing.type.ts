import { IThing } from '../../thing/thing.trait-collection';
import { ISmartPlugConfig } from './smart-plug-config.type';

export type ISmartPlugThing = IThing<ISmartPlugConfig>;

