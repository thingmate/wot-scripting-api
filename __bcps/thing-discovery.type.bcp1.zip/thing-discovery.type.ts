import { IAsyncTaskConstraint } from '@lirx/async-task/src/async-task/types/async-task-constraint.type';
import { AsyncValueObserverFactory } from '../async-value/methods/observer/async-value-observer-factory/async-value-observer-factory.class';
import { IGenericThing } from '../thing/thing.class';

export type IThingDiscovery<GThing extends IAsyncTaskConstraint<GThing, IGenericThing>> = AsyncValueObserverFactory<GThing>;
