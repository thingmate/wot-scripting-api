import { Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IThingPropertyWriteFunction<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
