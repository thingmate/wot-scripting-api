import { Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IThingPropertyObserveSinkFunction<GValue> {
  (
    value: GValue,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
