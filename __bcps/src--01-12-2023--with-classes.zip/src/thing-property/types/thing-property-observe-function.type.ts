import { IThingPropertyObserveSinkFunction } from './thing-property-observe-sink-function.type';
import { Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IThingPropertyObserveFunction<GValue> {
  (
    sink: IThingPropertyObserveSinkFunction<GValue>,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
