import { IAsyncTaskConstraint } from '@lirx/async-task';
import { IThingPropertyReadFunction } from './thing-property-read-function.type';
import { IThingPropertyWriteFunction } from './thing-property-write-function.type';
import { IThingPropertyObserveFunction } from './thing-property-observe-function.type';

export interface IThingPropertyInitOptions<GValue extends IAsyncTaskConstraint<GValue>> {
  readonly read: IThingPropertyReadFunction<GValue>;
  readonly write?: IThingPropertyWriteFunction<GValue> | undefined;
  readonly observe?: IThingPropertyObserveFunction<GValue> | undefined;
}
