import { IAsyncTaskConstraint, Abortable, IAsyncTaskInput } from '@lirx/async-task';

export interface IThingPropertyReadFunction<GValue extends IAsyncTaskConstraint<GValue>> {
  (
    abortable: Abortable,
  ): IAsyncTaskInput<GValue>;
}
