import { IPowerConsumptionHistory } from './type/power-consumption-history.type';
import { ThingProperty } from '../../thing-property.class';
import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const PowerConsumptionHistoryThingPropertyName = 'powerConsumptionHistory';

export type IPowerConsumptionHistoryThingPropertyName = typeof PowerConsumptionHistoryThingPropertyName;
export type IPowerConsumptionHistoryThingPropertyValue = readonly IPowerConsumptionHistory[];

export type IPowerConsumptionHistoryThingProperty = ThingProperty<IPowerConsumptionHistoryThingPropertyValue>;
export type INamedPowerConsumptionHistoryThingProperty = INamedThingProperty<IPowerConsumptionHistoryThingPropertyName, IPowerConsumptionHistoryThingProperty>;

