import { ThingProperty } from '../../thing-property.class';

import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const OnlineThingPropertyName = 'online';

export type IOnlineThingPropertyName = typeof OnlineThingPropertyName;
export type IOnlineThingPropertyValue = boolean;

export type IOnlineThingProperty = ThingProperty<IOnlineThingPropertyValue>;
export type INamedOnlineThingProperty = INamedThingProperty<IOnlineThingPropertyName, IOnlineThingProperty>;

