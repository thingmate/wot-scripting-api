import { ThingProperty } from '../../thing-property.class';

import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const TypeThingPropertyName = 'type';

export type ITypeThingPropertyName = typeof TypeThingPropertyName;
export type ITypeThingPropertyValue = string;

export type ITypeThingProperty = ThingProperty<ITypeThingPropertyValue>;
export type INamedTypeThingProperty = INamedThingProperty<ITypeThingPropertyName, ITypeThingProperty>;

