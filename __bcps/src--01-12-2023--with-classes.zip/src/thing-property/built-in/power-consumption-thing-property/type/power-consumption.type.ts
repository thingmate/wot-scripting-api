export interface IPowerConsumption {
  readonly current: number;
  readonly voltage: number;
  readonly power: number;
}
