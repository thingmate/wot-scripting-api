import { IPowerConsumption } from './type/power-consumption.type';
import { ThingProperty } from '../../thing-property.class';
import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const PowerConsumptionThingPropertyName = 'powerConsumption';

export type IPowerConsumptionThingPropertyName = typeof PowerConsumptionThingPropertyName;
export type IPowerConsumptionThingPropertyValue = IPowerConsumption;

export type IPowerConsumptionThingProperty = ThingProperty<IPowerConsumptionThingPropertyValue>;
export type INamedPowerConsumptionThingProperty = INamedThingProperty<IPowerConsumptionThingPropertyName, IPowerConsumptionThingProperty>;
