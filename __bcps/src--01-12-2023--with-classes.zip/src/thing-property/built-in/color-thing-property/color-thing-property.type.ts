import { IRGBCW } from './type/rgb-cw.type';
import { ThingProperty } from '../../thing-property.class';
import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const ColorThingPropertyName = 'color';

export type IColorThingPropertyName = typeof ColorThingPropertyName;
export type IColorThingPropertyValue = IRGBCW;

export type IColorThingProperty = ThingProperty<IColorThingPropertyValue>;
export type INamedColorThingProperty = INamedThingProperty<IColorThingPropertyName, IColorThingProperty>;

