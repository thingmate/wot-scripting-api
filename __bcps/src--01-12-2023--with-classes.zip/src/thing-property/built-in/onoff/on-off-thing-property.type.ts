import { IOnOff } from './type/on-off.type';
import { ThingProperty } from '../../thing-property.class';
import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const OnOffThingPropertyName = 'onoff';

export type IOnOffThingPropertyName = typeof OnOffThingPropertyName;
export type IOnOffThingPropertyValue = IOnOff;

export type IOnOffThingProperty = ThingProperty<IOnOffThingPropertyValue>;
export type INamedOnOffThingProperty = INamedThingProperty<IOnOffThingPropertyName, IOnOffThingProperty>;

