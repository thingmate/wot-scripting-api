import { ThingProperty } from '../../thing-property.class';

import { INamedThingProperty } from '../../../thing/types/named-thing-property.type';

export const TitleThingPropertyName = 'title';

export type ITitleThingPropertyName = typeof TitleThingPropertyName;
export type ITitleThingPropertyValue = string;

export type ITitleThingProperty = ThingProperty<ITitleThingPropertyValue>;
export type INamedTitleThingProperty = INamedThingProperty<ITitleThingPropertyName, ITitleThingProperty>;

