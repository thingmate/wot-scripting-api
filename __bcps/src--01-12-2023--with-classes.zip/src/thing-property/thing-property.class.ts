import { IAsyncTaskConstraint, Abortable, AsyncTask, IAsyncTaskInput, asyncTimeout } from '@lirx/async-task';
import { IThingPropertyReadFunction } from './types/thing-property-read-function.type';
import { IThingPropertyWriteFunction } from './types/thing-property-write-function.type';
import { IThingPropertyObserveSinkFunction } from './types/thing-property-observe-sink-function.type';
import { IThingPropertyObserveFunction } from './types/thing-property-observe-function.type';
import { IThingPropertyInitOptions } from './types/thing-property-init-options.type';

export class ThingProperty<GValue extends IAsyncTaskConstraint<GValue>> {
  readonly #read: IThingPropertyReadFunction<GValue>;
  readonly #write: IThingPropertyWriteFunction<GValue> | undefined;
  readonly #observe: IThingPropertyObserveFunction<GValue> | undefined;

  constructor(
    {
      read,
      write,
      observe,
    }: IThingPropertyInitOptions<GValue>,
  ) {
    this.#read = read;
    this.#write = write;
    this.#observe = observe;
  }

  read(
    abortable: Abortable,
  ): AsyncTask<GValue> {
    return AsyncTask.fromFactory<GValue>(this.#read, abortable);
  }

  get writable(): boolean {
    return this.#write !== void 0;
  }

  write(
    value: GValue,
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory<void>((abortable: Abortable): IAsyncTaskInput<void> => {
      if (this.#write === void 0) {
        throw new Error(`Non writable.`);
      } else {
        return this.#write(value, abortable);
      }
    }, abortable);
  }

  get observable(): boolean {
    return this.#observe !== void 0;
  }

  observe(
    sink: IThingPropertyObserveSinkFunction<GValue>,
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory<void>((abortable: Abortable): IAsyncTaskInput<void> => {
      if (this.#observe === void 0) {
        throw new Error(`Non observable.`);
      } else {
        return this.#observe(sink, abortable);
      }
    }, abortable);
  }

  spy(
    sink: IThingPropertyObserveSinkFunction<GValue>,
    period: number,
    abortable: Abortable,
  ): AsyncTask<void> {
    const loop = (
      abortable: Abortable,
    ): AsyncTask<void> => {
      const start: number = Date.now();
      return this.read(abortable)
        .successful((
          value: GValue,
          abortable: Abortable,
        ): IAsyncTaskInput<void> => {
          return sink(value, abortable);
        })
        .successful((
          _,
          abortable: Abortable,
        ): AsyncTask<void> => {
          return asyncTimeout(
            Math.max(0, period - (Date.now() - start)),
            abortable,
          );
        })
        .successful((
          _,
          abortable: Abortable,
        ): AsyncTask<void> => {
          return loop(abortable);
        });
    };

    return loop(abortable);
  }
}

export type IGenericThingProperty = ThingProperty<any>;
