import { IGenericThing } from '../../thing/thing.class';
import { Abortable, AsyncTask } from '@lirx/async-task';

export interface IThingCollectionListFunction<GThing extends IGenericThing> {
  (
    abortable: Abortable,
  ): AsyncTask<readonly GThing[]>;
}
