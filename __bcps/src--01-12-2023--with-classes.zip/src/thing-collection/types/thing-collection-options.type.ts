import { IGenericThing } from '../../thing/thing.class';

import { IThingCollectionListFunction } from './thing-collection-list-function.type';

export interface IThingCollectionOptions<GThing extends IGenericThing> {
  readonly list: IThingCollectionListFunction<GThing>;
}
