import { INamedOnlineThingProperty } from '../../../../thing-property/built-in/online/online-thing-property.type';
import { INamedOnOffThingProperty } from '../../../../thing-property/built-in/onoff/on-off-thing-property.type';
import { INamedColorThingProperty } from '../../../../thing-property/built-in/color-thing-property/color-thing-property.type';
import { INamedDescriptionThingProperty } from '../../../../thing-property/built-in/description/description-thing-property.type';

export type ISmartLightProperties =
  | INamedDescriptionThingProperty
  | INamedOnlineThingProperty
  | INamedOnOffThingProperty
  | INamedColorThingProperty
  ;
