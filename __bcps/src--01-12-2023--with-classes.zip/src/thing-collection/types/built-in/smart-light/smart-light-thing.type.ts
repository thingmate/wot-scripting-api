import { ISmartLightProperties } from './smart-light-properties.type';
import { Thing } from '../../../../thing/thing.class';

export type ISmartLightThing = Thing<ISmartLightProperties>;

