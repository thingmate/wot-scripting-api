import { ISmartPlugProperties } from './smart-plug-properties.type';
import { Thing } from '../../../../thing/thing.class';

export type ISmartPlugThing = Thing<ISmartPlugProperties>;

