import { AsyncTask, Abortable } from '@lirx/async-task';
import { IGenericThing } from '../thing/thing.class';
import { IThingCollectionOptions } from './types/thing-collection-options.type';
import { IThingCollectionListFunction } from './types/thing-collection-list-function.type';

export class ThingCollection<GThing extends IGenericThing> {
  readonly #list: IThingCollectionListFunction<GThing>;

  constructor(
    {
      list,
    }: IThingCollectionOptions<GThing>,
  ) {
    this.#list = list;
  }

  list(
    abortable: Abortable,
  ): AsyncTask<readonly GThing[]> {
    return this.#list(abortable);
  }
}

