import {
  InferGPropertyFromNamedPropertyAndName,
  InferGPropertyOfNamedProperty,
  InferGNameOfNamedProperty,
  IGenericNamedProperty,
  InferRecordFromNamedProperty,
} from './types/named-thing-property.type';
import { ThingProperty } from '../thing-property/thing-property.class';

export class Thing<GNamedThingProperty extends IGenericNamedProperty> {
  readonly #id: string; // ex: urn:uuid:0804d572-cce8-422a-bb7c-4412fcd56f06
  readonly #properties: ReadonlyMap<string, IGenericNamedProperty>;

  constructor(
    id: string,
    properties: Iterable<GNamedThingProperty> | InferRecordFromNamedProperty<GNamedThingProperty>,
  ) {
    this.#id = id;
    this.#properties = new Map<string, IGenericNamedProperty>(
      Symbol.iterator in (properties as any)
        ? properties as any
        : Object.fromEntries(properties as any) as Iterable<GNamedThingProperty>,
    );
  }

  get id(): string {
    return this.#id;
  }

  /* MISC */

  hasProperties(
    properties: Iterable<string>,
  ): boolean {
    const iterator: Iterator<string> = properties[Symbol.iterator]();
    let result: IteratorResult<string>;
    while (!(result = iterator.next()).done) {
      if (!this.has(result.value)) {
        return false;
      }
    }
    return true;
  }

  /* MAP */

  get size(): number {
    return this.#properties.size;
  }

  has(
    name: string,
  ): boolean {
    return this.#properties.has(name);
  }

  get<GName extends InferGNameOfNamedProperty<GNamedThingProperty>>(
    name: GName,
  ): InferGPropertyFromNamedPropertyAndName<GNamedThingProperty, GName> {
    if (this.#properties.has(name)) {
      return this.#properties.get(name)! as unknown as InferGPropertyFromNamedPropertyAndName<GNamedThingProperty, GName>;
    } else {
      throw new Error(`Property ${JSON.stringify(name)} does not exist.`);
    }
  }

  keys(): IterableIterator<InferGNameOfNamedProperty<GNamedThingProperty>> {
    return this.#properties.keys() as IterableIterator<InferGNameOfNamedProperty<GNamedThingProperty>>;
  }

  values(): IterableIterator<InferGPropertyOfNamedProperty<GNamedThingProperty>> {
    return this.#properties.values() as unknown as IterableIterator<InferGPropertyOfNamedProperty<GNamedThingProperty>>;
  }

  entries(): IterableIterator<GNamedThingProperty> {
    return this.#properties.entries() as unknown as IterableIterator<GNamedThingProperty>;
  }

  [Symbol.iterator](): IterableIterator<GNamedThingProperty> {
    return this.entries();
  }
}

export type IGenericThing = Thing<any>;


// const a = new Thing('a', {
//   'a': new ThingProperty<any>({} as any),
// });
//
// a.get('flow').
