import { ThingProperty, IGenericThingProperty } from '../../thing-property/thing-property.class';
import { UnionToIntersection } from '@lirx/utils';

export type INamedThingProperty<GName extends string, GProperty extends IGenericThingProperty> = readonly [
  name: GName,
  property: GProperty,
];

export type IGenericNamedProperty = INamedThingProperty<string, IGenericThingProperty>;

export type InferGNameOfNamedProperty<GNamedThingProperty extends IGenericNamedProperty> =
  GNamedThingProperty extends INamedThingProperty<infer GName, any>
    ? GName
    : never;

export type InferGPropertyOfNamedProperty<GNamedThingProperty extends IGenericNamedProperty> =
  GNamedThingProperty extends INamedThingProperty<any, infer GProperty>
    ? GProperty
    : never;

export type InferGPropertyFromNamedPropertyAndName<GNamedThingProperty extends IGenericNamedProperty, GName extends string> =
  GNamedThingProperty extends INamedThingProperty<GName, infer GProperty>
    ? GProperty
    : never;

export type InferRecordFromNamedProperty<GNamedThingProperty extends IGenericNamedProperty> = UnionToIntersection<
  GNamedThingProperty extends INamedThingProperty<infer GName, infer GProperty>
    ? Record<GName, GProperty>
    : never
>;
