import { INamedOnlineThingProperty } from '../../../thing-property/built-in/online/online-thing-property.type';
import { INamedOnOffThingProperty } from '../../../thing-property/built-in/onoff/on-off-thing-property.type';
import { INamedColorThingProperty } from '../../../thing-property/built-in/color-thing-property/color-thing-property.type';
import { INamedTitleThingProperty } from '../../../thing-property/built-in/title/title-thing-property.type';

export type ISmartLightProperties =
  | INamedOnlineThingProperty
  | INamedTitleThingProperty
  | INamedOnOffThingProperty
  | INamedColorThingProperty
  ;
