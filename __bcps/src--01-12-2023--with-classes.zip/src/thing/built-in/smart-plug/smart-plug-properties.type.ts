import { INamedTitleThingProperty } from '../../../thing-property/built-in/title/title-thing-property.type';
import { INamedOnlineThingProperty } from '../../../thing-property/built-in/online/online-thing-property.type';
import { INamedOnOffThingProperty } from '../../../thing-property/built-in/onoff/on-off-thing-property.type';
import {
  INamedPowerConsumptionThingProperty
} from '../../../thing-property/built-in/power-consumption-thing-property/power-consumption-thing-property.type';
import {
  INamedPowerConsumptionHistoryThingProperty
} from '../../../thing-property/built-in/power-consumption-history-thing-property/power-consumption-history-thing-property.type';

export type ISmartPlugProperties =
  | INamedOnlineThingProperty
  | INamedTitleThingProperty
  | INamedOnOffThingProperty
  | INamedPowerConsumptionThingProperty
  | INamedPowerConsumptionHistoryThingProperty
  ;
